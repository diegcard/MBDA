/*------Autoestudio 6------*/

CREATE TABLE staff(
    id varchar(20),
    name varchar(50) NOT NULL
);

CREATE TABLE modle(
    id varchar(20) NOT NULL,
    name varchar(50)
);

CREATE TABLE teaches(
    staff varchar(20) NOT NULL,
    event varchar(20) NOT NULL
);

/* A.Definiendo y poblando */
CREATE TABLE event(
    id VARCHAR2(20) NOT NULL,
    modle VARCHAR2(50) NOT NULL,
    kind CHAR(1) NOT NULL,
    dow VARCHAR2(15) NOT NULL,
    tod CHAR(5) NOT NULL,
    duration NUMBER(1) NOT NULL,
    room VARCHAR2(20) NULL,
    detail XMLTYPE
);

-- Checks

ALTER TABLE event ADD CONSTRAINT check_kind CHECK (kind='L' OR kind='T');
ALTER TABLE event ADD CONSTRAINT check_dow_days CHECK (dow='Monday' OR dow='Tuesday' OR dow='Wednesday' OR dow='Thursday' OR dow='Friday');
ALTER TABLE event ADD CONSTRAINT check_duration CHECK (duration = 1 OR duration = 2);
ALTER TABLE event ADD CONSTRAINT check_tod_range CHECK (SUBSTR(tod, 1, 2) BETWEEN '08' AND '20' AND SUBSTR(tod, 4, 2) BETWEEN '00' AND '59');

/*---------------------------------------------Atributos, Primarias, unicas, Foraneas---------------------------------------------*/
/*---------------------------------------------PRIMARY KEY---------------------------------------------*/
/*------------------------staff------------------------*/
ALTER TABLE staff ADD PRIMARY KEY(id);
ALTER TABLE modle ADD PRIMARY KEY(id);
ALTER TABLE event ADD PRIMARY KEY (id);
ALTER TABLE teaches ADD PRIMARY KEY(staff,event);

/*---------------------------------------------Unicas---------------------------------------------*/
ALTER TABLE modle ADD UNIQUE(name);

/*---------------------------------------------Foraneas---------------------------------------------*/
ALTER TABLE event ADD FOREIGN KEY (modle) REFERENCES modle(id);
ALTER TABLE teaches ADD FOREIGN KEY (staff) REFERENCES staff(id);
ALTER TABLE teaches ADD FOREIGN KEY (event) REFERENCES event(id);

-- Poblar 
/*------------------------------- staff -----------------------------*/

INSERT INTO staff VALUES('co.ACg','Cumming Andrew');
INSERT INTO staff VALUES('co.ACr','Crerar Dr Alison');
INSERT INTO staff VALUES('co.AFA','Armitage Dr Alistair');

/*--------------------------------modle-------------------------------*/
INSERT INTO modle VALUES('co12001','Rapid Application Development');
INSERT INTO modle VALUES('co12002','Software Development 1A');
INSERT INTO modle VALUES('co12003','Professional Skills');

/*--------------------------------event-------------------------------*/

INSERT INTO event VALUES (
    'co12001.L01',
    'co12004',
    'L',
    'Wednesday',
    '11:00',
    1,
    'cr.ACg',
    XMLTYPE('<detail>
               <evaluation>4</evaluation>
               <comments>
                  <comment>Excelente evento</comment>
                  <comment>Muy instructivo</comment>
               </comments>
               <bibliography>
                  <reference>
                     <title>Libro 1</title>
                     <url>http://ejemplo.com/libro1</url>
                     <type>texto</type>
                  </reference>
                  <reference>
                     <title>Video tutorial</title>
                     <url>http://ejemplo.com/video</url>
                     <type>video</type>
                  </reference>
               </bibliography>
            </detail>')
);

INSERT INTO event VALUES (
    'co12002.L02',
    'co12004',
    'L',
    'Monday',
    '17:00',
    1,
    'co.ACr',
    XMLTYPE('<detail>
               <evaluation>3</evaluation>
               <comments>
                  <comment>Evento interesante</comment>
                  <comment>Podría mejorar</comment>
               </comments>
               <bibliography>
                  <reference>
                     <title>Artículo 1</title>
                     <url>http://ejemplo.com/articulo1</url>
                     <type>texto</type>
                  </reference>
                  <reference>
                     <title>Podcast educativo</title>
                     <url>http://ejemplo.com/podcast</url>
                     <type>audio</type>
                  </reference>
               </bibliography>
            </detail>')
);

INSERT INTO event VALUES (
    'co12003.T01',
    'co12004',
    'T',
    'Monday',
    '11:00',
    2,
    'co.AFA',
    XMLTYPE('<detail>
               <evaluation>5</evaluation>
               <comments>
                  <comment>Increíble evento</comment>
                  <comment>Muy informativo</comment>
               </comments>
               <bibliography>
                  <reference>
                     <title>Libro recomendado</title>
                     <url>http://ejemplo.com/libro</url>
                     <type>texto</type>
                  </reference>
                  <reference>
                     <title>Entrevista en video</title>
                     <url>http://ejemplo.com/entrevista</url>
                     <type>video</type>
                  </reference>
               </bibliography>
            </detail>')
);


/*--------------------------------event-------------------------------*/
INSERT INTO teaches VALUES('co.ACg','co12001.L01');
INSERT INTO teaches VALUES('co.ACr','co12002.L02');
INSERT INTO teaches VALUES('co.AFA','co42010.T01');

/*B. Consultando */
-- 1. Bibliografía de un evento específico.
SELECT
   XMLTable('/event/detail/bibliography/reference'
            PASSING detail
            COLUMNS title VARCHAR2(50) PATH 'title',
                    url VARCHAR2(255) PATH 'url',
                    type VARCHAR2(10) PATH 'type') AS bibliografia
FROM event
WHERE id = 'co12004.L01';

-- 2. Eventos con evaluaciones mayores a 4.0.
SELECT id, modle
FROM event
WHERE XMLExists('/event/detail/evaluation/text() > 4'
                 PASSING detail);

-- 3. Primer comentario de todos los eventos que tienen comentarios.
SELECT id,
       XMLTable('/event/detail/comments/comment[1]'
                PASSING detail
                COLUMNS comentario VARCHAR2(255) PATH '.') AS primer_comentario
FROM event
WHERE XMLExists('/event/detail/comments/comment'
                 PASSING detail);

-- 4. Obtener todos los eventos con su evaluacion y duracion
SELECT id,
       XMLTable('/event/detail'
                PASSING detail
                COLUMNS evaluation NUMBER(1) PATH 'evaluation',
                        duration NUMBER(1) PATH 'duration') AS evaluation_duration
FROM event;

-- 5. Consulta para generar un XML que contenga solo eventos con comentarios
SELECT dbms_xmlgen.getxmltype(
          XMLQuery('/event[detail/comments/comment]'
                   PASSING detail
                   RETURNING CONTENT)) AS events_with_comments
FROM event
WHERE XMLExists('/event/detail/comments/comment'
                 PASSING detail);

