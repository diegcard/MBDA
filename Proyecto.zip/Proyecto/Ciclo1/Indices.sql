CREATE INDEX idx_idPersona ON Personas(idPersona);
CREATE INDEX idx_idVenta ON Ventas(idVenta);
CREATE INDEX idx_idProducto ON Productos(idProducto);
CREATE INDEX idx_idCompras ON Compras(idCompra);