--Clientes
INSERT INTO Clientes (idPersona, ocupacion, ingresos, historialCredito)
VALUES (1, 'Ingeniero', 500000, 80);
INSERT INTO Clientes (idPersona, ocupacion, ingresos, historialCredito)
VALUES (2, 'Medico', 800000, 90);
INSERT INTO Clientes (idPersona, ocupacion, ingresos, historialCredito)
VALUES (3, 'Contador', 600000, 70);
INSERT INTO Clientes (idPersona, ocupacion, ingresos, historialCredito)
VALUES (4, 'Enfermera', 400000, 85);
INSERT INTO Clientes (idPersona, ocupacion, ingresos, historialCredito)
VALUES (5, 'Profesor', 350000, 60);