INSERT INTO Ventas (idVenta, idEmpleado, idCliente, descripcionVenta, estadoVenta)
VALUES (1, 6, 1, 'Venta de moto', 'A');
INSERT INTO Ventas (idVenta, idEmpleado, idCliente, descripcionVenta, estadoVenta)
VALUES (2, 6, 2, 'Venta de Repuestos', 'A');
INSERT INTO Ventas (idVenta, idEmpleado, idCliente, descripcionVenta, estadoVenta)
VALUES (3, 6, 3, 'Venta Accesorios', 'A');
INSERT INTO Ventas (idVenta, idEmpleado, idCliente, descripcionVenta, estadoVenta)
VALUES (4, 6, 1, 'Venta de moto', 'A');
INSERT INTO Ventas (idVenta, idEmpleado, idCliente, descripcionVenta, estadoVenta)
VALUES (5, 6, 1, 'Venta de moto', 'A');