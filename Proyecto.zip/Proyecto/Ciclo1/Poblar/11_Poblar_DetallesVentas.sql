INSERT INTO DetallesVentas (idDetalleVenta, idVenta, idProducto, cantidad, precioUnitario)
VALUES (1, 1, 'M1', 1, 12000000);
INSERT INTO DetallesVentas (idDetalleVenta, idVenta, idProducto, cantidad, precioUnitario)
VALUES (2, 1, 'M4', 2, 7100000);
INSERT INTO DetallesVentas (idDetalleVenta, idVenta, idProducto, cantidad, precioUnitario)
VALUES (3, 1, 'M5', 3, 12400000);

INSERT INTO DetallesVentas (idDetalleVenta, idVenta, idProducto, cantidad, precioUnitario)
VALUES (4, 2, 'A1', 2, 50000);
INSERT INTO DetallesVentas (idDetalleVenta, idVenta, idProducto, cantidad, precioUnitario)
VALUES (5, 2, 'A2', 2, 30000);

INSERT INTO DetallesVentas (idDetalleVenta, idVenta, idProducto, cantidad, precioUnitario)
VALUES (6, 3, 'R1', 2, 200000);

INSERT INTO DetallesVentas (idDetalleVenta, idVenta, idProducto, cantidad, precioUnitario)
VALUES (7, 4, 'R2', 2, 540000);

INSERT INTO DetallesVentas (idDetalleVenta, idVenta, idProducto, cantidad, precioUnitario)
VALUES (8, 4, 'R5', 2, 30000);