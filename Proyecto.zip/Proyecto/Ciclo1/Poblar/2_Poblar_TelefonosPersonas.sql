--telefonosPersonas
INSERT INTO telefonosPersona (idPersona, telefono)
VALUES (1, '3001234567');
INSERT INTO telefonosPersona (idPersona, telefono)
VALUES (2, '3007654321');
INSERT INTO telefonosPersona (idPersona, telefono)
VALUES (3, '3001597531');
INSERT INTO telefonosPersona (idPersona, telefono)
VALUES (4, '3003579514');
INSERT INTO telefonosPersona (idPersona, telefono)
VALUES (5, '3009541268');
INSERT INTO telefonosPersona (idPersona, telefono)
VALUES (6, '3001234567');
INSERT INTO telefonosPersona (idPersona, telefono)
VALUES (7, '3001456987');
INSERT INTO telefonosPersona (idPersona, telefono)
VALUES (8, '30069874587');
INSERT INTO telefonosPersona (idPersona, telefono)
VALUES (9, '30065841238');
INSERT INTO telefonosPersona (idPersona, telefono)
VALUES (10, '3145698745');
