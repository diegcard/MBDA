INSERT INTO Accesorios (idProducto, descripcion)
VALUES ('A1', 'Cascos talla L');
INSERT INTO Accesorios (idProducto, descripcion)
VALUES ('A2', 'Guantes talla L');