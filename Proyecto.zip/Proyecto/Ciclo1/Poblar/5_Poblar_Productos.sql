-- Producto
INSERT INTO Productos (idProducto, nombre, precio, cantidadEnStock, tipoProducto)
VALUES ('M1', 'Moto RX150', 12000000, 0, 'M');
INSERT INTO Productos (idProducto, nombre, precio, cantidadEnStock, tipoProducto)
VALUES ('M2', 'Moto Honda XBlade 160', 12500000, 0, 'M');
INSERT INTO Productos (idProducto, nombre, precio, cantidadEnStock, tipoProducto)
VALUES ('M3', 'Moto Gixxer 250', 15000000, 0, 'M');
INSERT INTO Productos (idProducto, nombre, precio, cantidadEnStock, tipoProducto)
VALUES ('M4', 'Moto Honda CB 125F 2024', 7100000, 0, 'M');
INSERT INTO Productos (idProducto, nombre, precio, cantidadEnStock, tipoProducto)
VALUES ('M5', 'Moto Honda CB 190R Repsol 2024', 12400000, 0, 'M');


INSERT INTO Productos (idProducto, nombre, precio, cantidadEnStock, tipoProducto)
VALUES ('R1', 'Disco de freno', 200000, 0, 'R');
INSERT INTO Productos (idProducto, nombre, precio, cantidadEnStock, tipoProducto)
VALUES ('R2', 'Llanta', 540000, 0, 'R');
INSERT INTO Productos (idProducto, nombre, precio, cantidadEnStock, tipoProducto)
VALUES ('R3', 'Espejos', 150000, 0, 'R');
INSERT INTO Productos (idProducto, nombre, precio, cantidadEnStock, tipoProducto)
VALUES ('R4', 'Aceite', 75000, 0, 'R');
INSERT INTO Productos (idProducto, nombre, precio, cantidadEnStock, tipoProducto)
VALUES ('R5', 'Bujias', 30000, 0, 'R');


INSERT INTO Productos (idProducto, nombre, precio, cantidadEnStock, tipoProducto)
VALUES ('A1', 'Casco', 50000, 0, 'A');
INSERT INTO Productos (idProducto, nombre, precio, cantidadEnStock, tipoProducto)
VALUES ('A2', 'Guantes', 30000, 0, 'A');