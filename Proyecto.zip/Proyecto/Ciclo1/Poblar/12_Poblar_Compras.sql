INSERT INTO Compras (idCompra, idProveedor, idEmpleado, estadoCompra, descripcionCompra)
VALUES (1, 1, 6, 'A', 'Compra de Motos');

INSERT INTO Compras (idCompra, idProveedor, idEmpleado, estadoCompra, descripcionCompra)
VALUES (2, 2, 7, 'C', 'Compra de Repuestos');

INSERT INTO Compras (idCompra, idProveedor, idEmpleado, estadoCompra, descripcionCompra)
VALUES (3, 3, 8, 'P', 'Compra de Accesorios');

INSERT INTO Compras (idCompra, idProveedor, idEmpleado, estadoCompra, descripcionCompra)
VALUES (4, 4, 9, 'F', 'Compra de Motos');

INSERT INTO Compras (idCompra, idProveedor, idEmpleado, estadoCompra)
VALUES (5, 4, 6, 'E');
