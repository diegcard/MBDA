INSERT INTO Repuestos(idProducto, tipo, descripcion)
VALUES('R1', 'Frenos', 'Kit de fernos de disco para moto de 160 cc');
INSERT INTO Repuestos(idProducto, tipo, descripcion)
VALUES('R2', 'Neumaticos', 'LLanta de 23');
INSERT INTO Repuestos(idProducto, tipo, descripcion)
VALUES('R3', 'Espejos', 'Kit de Epejos Generico');
INSERT INTO Repuestos(idProducto, tipo, descripcion)
VALUES('R4', 'Aceite', 'Galon de Aceite para moto');
INSERT INTO Repuestos(idProducto, tipo, descripcion)
VALUES('R5', 'Motor', 'Bujias para motor');