--xd
INSERT INTO Motos (idProducto, marca, modelo, anio, color, cilindraje, descripcion)
VALUES ('M1', 'Honda','Sport', TO_DATE('2024', 'YYYY'), 'Rojo', 150, 'Ninguna');
INSERT INTO Motos (idProducto, marca, modelo, anio, color, cilindraje, descripcion)
VALUES ('M2', 'Honda','Sport', TO_DATE('2024', 'YYYY'), 'Rojo', 165, NULL);
INSERT INTO Motos (idProducto, marca, modelo, anio, color, cilindraje, descripcion)
VALUES ('M3', 'Suzuki','Sport', TO_DATE('2023', 'YYYY'), 'Negro', 250, NULL);
INSERT INTO Motos (idProducto, marca, modelo, anio, color, cilindraje, descripcion)
VALUES ('M4', 'Honda','Sport', TO_DATE('2024', 'YYYY'), 'Blanca', 125, NULL);
INSERT INTO Motos (idProducto, marca, modelo, anio, color, cilindraje, descripcion)
VALUES ('M5', 'Honda','Sport', TO_DATE('2024', 'YYYY'), 'Negro', 190, NULL);
