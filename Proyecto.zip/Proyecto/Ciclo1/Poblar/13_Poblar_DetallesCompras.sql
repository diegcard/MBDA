INSERT INTO DetallesCompras (idDetalleCompra, idCompra, idProducto, cantidad, precioUnitario)
VALUES (1, 1, 'M1', 20, 10000000);
INSERT INTO DetallesCompras (idDetalleCompra, idCompra, idProducto, cantidad, precioUnitario)
VALUES (2, 1, 'M2', 10, 11000000);
INSERT INTO DetallesCompras (idDetalleCompra, idCompra, idProducto, cantidad, precioUnitario)
VALUES (3, 1, 'M3', 10, 13000000);
INSERT INTO DetallesCompras (idDetalleCompra, idCompra, idProducto, cantidad, precioUnitario)
VALUES (4, 1, 'M4', 10, 5000000);
INSERT INTO DetallesCompras (idDetalleCompra, idCompra, idProducto, cantidad, precioUnitario)
VALUES (5, 4, 'M5', 10, 10000000);


INSERT INTO DetallesCompras (idDetalleCompra, idCompra, idProducto, cantidad, precioUnitario)
VALUES (6, 2, 'R1', 20, 150000);
INSERT INTO DetallesCompras (idDetalleCompra, idCompra, idProducto, cantidad, precioUnitario)
VALUES (7, 2, 'R2', 20, 390000);
INSERT INTO DetallesCompras (idDetalleCompra, idCompra, idProducto, cantidad, precioUnitario)
VALUES (8, 2, 'R3', 20, 100000);
INSERT INTO DetallesCompras (idDetalleCompra, idCompra, idProducto, cantidad, precioUnitario)
VALUES (9, 2, 'R4', 20, 50000);
INSERT INTO DetallesCompras (idDetalleCompra, idCompra, idProducto, cantidad, precioUnitario)
VALUES (10, 2, 'R5', 20, 25000);

INSERT INTO DetallesCompras (idDetalleCompra, idCompra, idProducto, cantidad, precioUnitario)
VALUES (11, 3, 'A1', 20, 40000);
INSERT INTO DetallesCompras (idDetalleCompra, idCompra, idProducto, cantidad, precioUnitario)
VALUES (12, 3, 'A2', 20, 27000);