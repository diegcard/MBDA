-- Insertar datos en la tabla Proveedores
INSERT INTO Proveedores (idProveedor, nombre, direccion, correoElectronico, informacionContacto)
VALUES ('1', 'Proveedor A', 'Calle 123, Ciudad A', 'proveedora@example.com', 'Persona de contacto: Juan, Teléfono: 123-456-789');
INSERT INTO Proveedores (idProveedor, nombre, direccion, correoElectronico, informacionContacto)
VALUES ('2', 'Proveedor B', 'Avenida 456, Ciudad B', 'proveedorb@example.com', 'Persona de contacto: Maria, Teléfono: 987-654-321');
INSERT INTO Proveedores (idProveedor, nombre, direccion, correoElectronico, informacionContacto)
VALUES ('3', 'Proveedor C', 'Ruta 789, Ciudad C', 'proveedorc@example.com', 'Persona de contacto: Carlos, Teléfono: 456-123-789');
INSERT INTO Proveedores (idProveedor, nombre, direccion, correoElectronico, informacionContacto)
VALUES ('4', 'Proveedor D', 'Camino 456, Ciudad D', 'proveedord@example.com', 'Persona de contacto: Laura, Teléfono: 789-456-123');
INSERT INTO Proveedores (idProveedor, nombre, direccion, correoElectronico, informacionContacto)
VALUES ('5', 'Proveedor E', 'Plaza 123, Ciudad E', 'proveedore@example.com', 'Persona de contacto: Sergio, Teléfono: 321-654-987');
INSERT INTO Proveedores (idProveedor, nombre, direccion, correoElectronico, informacionContacto)
VALUES ('6', 'Proveedor F', 'Boulevard 789, Ciudad F', 'proveedorf@example.com', 'Persona de contacto: Elena, Teléfono: 654-321-987');
INSERT INTO Proveedores (idProveedor, nombre, direccion, correoElectronico, informacionContacto)
VALUES ('7', 'Proveedor G', 'Callejón 123, Ciudad G', 'proveedorg@example.com', 'Persona de contacto: Javier, Teléfono: 987-321-654');
INSERT INTO Proveedores (idProveedor, nombre, direccion, correoElectronico, informacionContacto)
VALUES ('8', 'Proveedor H', 'Carrera 456, Ciudad H', 'proveedorh@example.com', 'Persona de contacto: Ana, Teléfono: 789-123-456');
INSERT INTO Proveedores (idProveedor, nombre, direccion, correoElectronico, informacionContacto)
VALUES ('9', 'Proveedor I', 'Paseo 789, Ciudad I', 'proveedori@example.com', 'Persona de contacto: Luis, Teléfono: 456-789-123');