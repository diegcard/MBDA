-- Empleados
INSERT INTO Empleados (idPersona, sexo, etadoCivil, cargo, salario)
VALUES (6, 'M', 'S', 'Vendedor', 1200000);
INSERT INTO Empleados (idPersona, sexo, etadoCivil, cargo, salario)
VALUES (7, 'H', 'C', 'Vendedor', 1500000);
INSERT INTO Empleados (idPersona, sexo, etadoCivil, cargo, salario)
VALUES (8, 'M', 'V', 'Mecanico', 1000000);
INSERT INTO Empleados (idPersona, sexo, etadoCivil, cargo, salario)
VALUES (9, 'M', 'S', 'Administrador', 900000);
INSERT INTO Empleados (idPersona, sexo, etadoCivil, cargo, salario)
VALUES (10, 'H', 'C', 'Gerente', 200000000);
