-- Test case 1: Valid input for AD_Proveedor
BEGIN
    PC_COMPRAS.AD_Proveedor('Proveedor1', 'Dirección1', 'correo1@example.com', 'Contacto1');
    COMMIT;
    DBMS_OUTPUT.PUT_LINE('Test case 1 passed');
EXCEPTION
    WHEN OTHERS THEN
        ROLLBACK;
        DBMS_OUTPUT.PUT_LINE('Test case 1 failed');
END;

-- Test case 2: Valid input for MO_Proveedor
BEGIN
    PC_COMPRAS.MO_Proveedor(1, 'Proveedor1', 'Nueva Dirección', 'nuevo_correo@example.com', 'Nuevo Contacto');
    COMMIT;
    DBMS_OUTPUT.PUT_LINE('Test case 2 passed');
EXCEPTION
    WHEN OTHERS THEN
        ROLLBACK;
        DBMS_OUTPUT.PUT_LINE('Test case 2 failed');
END;

-- Test case 3: Valid input for EL_Proveedor
BEGIN
    PC_COMPRAS.EL_Proveedor(1);
    COMMIT;
    DBMS_OUTPUT.PUT_LINE('Test case 3 passed');
EXCEPTION
    WHEN OTHERS THEN
        ROLLBACK;
        DBMS_OUTPUT.PUT_LINE('Test case 3 failed');
END;

-- Test case 4: Valid input for AD_telefono
BEGIN
    PC_COMPRAS.AD_telefono('Proveedor1', 123456789);
    COMMIT;
    DBMS_OUTPUT.PUT_LINE('Test case 4 passed');
EXCEPTION
    WHEN OTHERS THEN
        ROLLBACK;
        DBMS_OUTPUT.PUT_LINE('Test case 4 failed');
END;

-- Test case 5: Valid input for EL_telefono
BEGIN
    PC_COMPRAS.EL_telefono('Proveedor1', 123456789);
    COMMIT;
    DBMS_OUTPUT.PUT_LINE('Test case 5 passed');
EXCEPTION
    WHEN OTHERS THEN
        ROLLBACK;
        DBMS_OUTPUT.PUT_LINE('Test case 5 failed');
END;

-- Test case 6: Valid input for AD_Compra
BEGIN
    PC_COMPRAS.AD_Compra('Proveedor1', 'Empleado1', 'A', 'Descripción1');
    COMMIT;
    DBMS_OUTPUT.PUT_LINE('Test case 6 passed');
EXCEPTION
    WHEN OTHERS THEN
        ROLLBACK;
        DBMS_OUTPUT.PUT_LINE('Test case 6 failed');
END;

-- Test case 7: Valid input for MO_Compra
BEGIN
    PC_COMPRAS.MO_Compra(1, 'B', 'Nueva Descripción');
    COMMIT;
    DBMS_OUTPUT.PUT_LINE('Test case 7 passed');
EXCEPTION
    WHEN OTHERS THEN
        ROLLBACK;
        DBMS_OUTPUT.PUT_LINE('Test case 7 failed');
END;

-- Test case 8: Valid input for EL_Compra
BEGIN
    PC_COMPRAS.EL_Compra(1);
    COMMIT;
    DBMS_OUTPUT.PUT_LINE('Test case 8 passed');
EXCEPTION
    WHEN OTHERS THEN
        ROLLBACK;
        DBMS_OUTPUT.PUT_LINE('Test case 8 failed');
END;

-- Test case 9: Valid input for AD_DetalleCompra
BEGIN
    PC_COMPRAS.AD_DetalleCompra(1, 'Producto1', 10, 9.99);
    COMMIT;
    DBMS_OUTPUT.PUT_LINE('Test case 9 passed');
EXCEPTION
    WHEN OTHERS THEN
        ROLLBACK;
        DBMS_OUTPUT.PUT_LINE('Test case 9 failed');
END;

-- Test case 10: Valid input for EL_DetalleCompra
BEGIN
    PC_COMPRAS.EL_DetalleCompra(1);
    COMMIT;
    DBMS_OUTPUT.PUT_LINE('Test case 10 passed');
EXCEPTION
    WHEN OTHERS THEN
        ROLLBACK;
        DBMS_OUTPUT.PUT_LINE('Test case 10 failed');
END;

-- Test case 11: Valid input for CO_Proveedor
DECLARE
    c_cursor SYS_REFCURSOR;
BEGIN
    c_cursor := PC_COMPRAS.CO_Proveedor;
    -- Process the cursor data as needed
    DBMS_OUTPUT.PUT_LINE('Test case 11 passed');
EXCEPTION
    WHEN OTHERS THEN
        DBMS_OUTPUT.PUT_LINE('Test case 11 failed');
END;

-- Test case 12: Valid input for CO_telefono
DECLARE
    c_cursor SYS_REFCURSOR;
BEGIN
    c_cursor := PC_COMPRAS.CO_telefono;
    -- Process the cursor data as needed
    DBMS_OUTPUT.PUT_LINE('Test case 12 passed');
EXCEPTION
    WHEN OTHERS THEN
        DBMS_OUTPUT.PUT_LINE('Test case 12 failed');
END;

-- Test case 13: Valid input for CO_Compras
DECLARE
    c_cursor SYS_REFCURSOR;
BEGIN
    c_cursor := PC_COMPRAS.CO_Compras;
    -- Process the cursor data as needed
    DBMS_OUTPUT.PUT_LINE('Test case 13 passed');
EXCEPTION
    WHEN OTHERS THEN
        DBMS_OUTPUT.PUT_LINE('Test case 13 failed');
END;

-- Test case 14: Valid input for CO_DetalleCompras
DECLARE
    c_cursor SYS_REFCURSOR;
BEGIN
    c_cursor := PC_COMPRAS.CO_DetalleCompras;
    -- Process the cursor data as needed
    DBMS_OUTPUT.PUT_LINE('Test case 14 passed');
EXCEPTION
    WHEN OTHERS THEN
        DBMS_OUTPUT.PUT_LINE('Test case 14 failed');
END;

-- Test case 15: Valid input for CO_DetallesCompraEspecifico
DECLARE
    c_cursor SYS_REFCURSOR;
BEGIN
    c_cursor := PC_COMPRAS.CO_DetallesCompraEspecifico(1);
    -- Process the cursor data as needed
    DBMS_OUTPUT.PUT_LINE('Test case 15 passed');
EXCEPTION
    WHEN OTHERS THEN
        DBMS_OUTPUT.PUT_LINE('Test case 15 failed');
END;