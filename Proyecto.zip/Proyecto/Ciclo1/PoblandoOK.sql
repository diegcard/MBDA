--Insert Clientes
EXECUTE PC_PERSONA.AD_Cliente (52083589, 'C.C' ,'Cristina', 'Acosta', 'Calle 65 # 86-69', 'Cristina@gmail.com', 'Conductora',3200000, 560);
EXECUTE PC_PERSONA.AD_Cliente (627103481, 'T.I', 'Reuven', 'Pasek', '2 Hallows Trail', 'rpasek0@usda.gov', 'artista', 6772679, 492);
EXECUTE PC_PERSONA.AD_Cliente (3809013844, 'C.C', 'Lindy', 'Petrelluzzi', '1 Dennis Junction', 'lpetrelluzzi1@ucoz.ru', 'profesor', 9950297, 646);
EXECUTE PC_PERSONA.AD_Cliente (5138161147, 'C.C', 'Eada', 'Hagergham', '81 Sauthoff Road', 'ehagergham2@blogs.com', 'abogado', 5330830, 64);
EXECUTE PC_PERSONA.AD_Cliente (4657596103, 'C.C', 'Gerty', 'Kemmey', '937 Express Street', 'gkemmey3@zdnet.com', 'músico', 2118773, 846);
EXECUTE PC_PERSONA.AD_Cliente (5768482920, 'C.E', 'Ricardo', 'O''Hone', '5013 Shasta Park', 'rohone4@auda.org.au', 'cocinero', 9093587, 895);
EXECUTE PC_PERSONA.AD_Cliente (7594912166, 'C.E', 'Nichole', 'Tebbett', '1 Warner Street', 'ntebbett5@wikipedia.org', 'artista', 6426418, 34);
EXECUTE PC_PERSONA.AD_Cliente (5017304972, 'T.I', 'Rice', 'Hammond', '16 Elmside Hill', 'rhammond6@ft.com', 'profesor', 2369711, 956);
EXECUTE PC_PERSONA.AD_Cliente (6467266295, 'C.E', 'Corry', 'Munnings', '263 Schurz Junction', 'cmunnings7@google.es', 'músico', 2651672, 237);
EXECUTE PC_PERSONA.AD_Cliente (4833528332, 'C.E', 'Anna-diana', 'Zarfat', '174 Ridgeview Park', 'azarfat8@usgs.gov', 'abogado', 2432874, 852);
EXECUTE PC_PERSONA.AD_Cliente (4500036181, 'C.C', 'Emiline', 'Hasnney', '49352 Weeping Birch Road', 'ehasnney9@godaddy.com', 'escritor', 3800996, 410);
EXECUTE PC_PERSONA.AD_Cliente (3327415902, 'C.E', 'Adolphus', 'Cribbott', '5 Ryan Place', 'acribbotta@people.com.cn', 'abogado', 7350906, 788);
EXECUTE PC_PERSONA.AD_Cliente (1837008623, 'T.I', 'Cecile', 'Muncey', '02857 Pawling Plaza', 'cmunceyb@engadget.com', 'profesor', 7684706, 518);
EXECUTE PC_PERSONA.AD_Cliente (1945071414, 'C.C', 'Consalve', 'Cammoile', '854 Grasskamp Pass', 'ccammoilec@i2i.jp', 'científico', 6014981, 451);
EXECUTE PC_PERSONA.AD_Cliente (5924611256, 'T.I', 'Gary', 'Lonergan', '66881 Erie Crossing', 'glonergand@dedecms.com', 'músico', 9211817, 325);
EXECUTE PC_PERSONA.AD_Cliente (2355698099, 'C.E', 'Jodie', 'Potier', '79718 Roxbury Street', 'jpotiere@shinystat.com', 'músico', 7221257, 740);
EXECUTE PC_PERSONA.AD_Cliente (475378356, 'C.E', 'Maximilianus', 'Fallanche', '6 Donald Drive', 'mfallanchef@scientificamerican.com', 'escritor', 3421457, 90);
EXECUTE PC_PERSONA.AD_Cliente (8403198931, 'T.I', 'Chauncey', 'Toffolo', '6854 Village Green Plaza', 'ctoffolog@163.com', 'cocinero', 1831150, 631);
EXECUTE PC_PERSONA.AD_Cliente (7919748234, 'C.E', 'Shell', 'Marvelley', '5 Northridge Road', 'smarvelleyh@flickr.com', 'abogado', 9790510, 261);
EXECUTE PC_PERSONA.AD_Cliente (9662504327, 'T.I', 'Serena', 'Serrier', '5 Killdeer Pass', 'sserrieri@meetup.com', 'atleta', 5856532, 763);
EXECUTE PC_PERSONA.AD_Cliente (6280574537, 'C.C', 'Dorelle', 'Barnsley', '286 Kipling Road', 'dbarnsleyj@fema.gov', 'médico', 7835075, 301);
EXECUTE PC_PERSONA.AD_Cliente (6606975420, 'T.I', 'Sheffy', 'Lazare', '6 Heffernan Lane', 'slazarek@abc.net.au', 'artista', 6706457, 671);
EXECUTE PC_PERSONA.AD_Cliente (883153451, 'C.E', 'Rachel', 'Fauning', '92850 Forest Run Road', 'rfauningl@miibeian.gov.cn', 'científico', 2756523, 782);
EXECUTE PC_PERSONA.AD_Cliente (8472882641, 'C.E', 'Scotti', 'Pedreschi', '0 Roth Trail', 'spedreschim@wikipedia.org', 'ingeniero', 5894194, 259);
EXECUTE PC_PERSONA.AD_Cliente (2668629156, 'C.E', 'Jody', 'Drance', '1780 Linden Road', 'jdrancen@virginia.edu', 'artista', 8707948, 985);
EXECUTE PC_PERSONA.AD_Cliente (2521255991, 'C.C', 'Lulita', 'McVeigh', '8 Golf Junction', 'lmcveigho@xing.com', 'escritor', 8686455, 520);
EXECUTE PC_PERSONA.AD_Cliente (5520683759, 'T.I', 'Camella', 'Langmaid', '3 Pawling Way', 'clangmaidp@skyrock.com', 'médico', 9834241, 325);
EXECUTE PC_PERSONA.AD_Cliente (5359073874, 'T.I', 'Katinka', 'Novik', '606 Manufacturers Hill', 'knovikq@360.cn', 'ingeniero', 5724594, 269);
EXECUTE PC_PERSONA.AD_Cliente (7676173531, 'C.E', 'Pearle', 'Bibey', '7 Thackeray Street', 'pbibeyr@aboutads.info', 'atleta', 9949452, 266);
EXECUTE PC_PERSONA.AD_Cliente (6384426089, 'T.I', 'Marcelia', 'Mattack', '0 Hazelcrest Way', 'mmattacks@tamu.edu', 'artista', 8762824, 604);
EXECUTE PC_PERSONA.AD_Cliente (901518410, 'C.E', 'Marline', 'Espinoza', '606 Utah Point', 'mespinozat@businessweek.com', 'profesor', 8287326, 248);
EXECUTE PC_PERSONA.AD_Cliente (1500188861, 'C.E', 'Barty', 'Dooly', '20422 Wayridge Point', 'bdoolyu@mediafire.com', 'abogado', 197090, 571);
EXECUTE PC_PERSONA.AD_Cliente (3579481322, 'C.C', 'Maressa', 'Fitton', '23 Tennessee Park', 'mfittonv@ucoz.ru', 'médico', 5253629, 395);
EXECUTE PC_PERSONA.AD_Cliente (5712171614, 'T.I', 'Sorcha', 'Seys', '64 Blaine Court', 'sseysw@simplemachines.org', 'abogado', 4880010, 889);
EXECUTE PC_PERSONA.AD_Cliente (6831605458, 'C.E', 'Fergus', 'Sacchetti', '24 Dorton Court', 'fsacchettix@theglobeandmail.com', 'ingeniero', 866499, 624);
EXECUTE PC_PERSONA.AD_Cliente (2306470520, 'T.I', 'Katlin', 'Kadwallider', '0 Schurz Court', 'kkadwallidery@gmpg.org', 'atleta', 1305669, 726);
EXECUTE PC_PERSONA.AD_Cliente (2412348196, 'C.E', 'Bertie', 'Fforde', '55 Shelley Parkway', 'bffordez@acquirethisname.com', 'músico', 4812661, 226);
EXECUTE PC_PERSONA.AD_Cliente (5790249503, 'T.I', 'Park', 'Deeves', '3104 Warrior Lane', 'pdeeves10@nba.com', 'profesor', 7818440, 340);
EXECUTE PC_PERSONA.AD_Cliente (6723245100, 'T.I', 'Fae', 'Sweatland', '9175 Jenna Avenue', 'fsweatland11@vistaprint.com', 'atleta', 5862586, 220);
EXECUTE PC_PERSONA.AD_Cliente (5984192055, 'C.C', 'Raffarty', 'Baston', '37 Crescent Oaks Pass', 'rbaston12@scribd.com', 'científico', 3064612, 79);
EXECUTE PC_PERSONA.AD_Cliente (7227656423, 'T.I', 'Bernelle', 'Thurby', '883 Warrior Plaza', 'bthurby13@wikispaces.com', 'médico', 4751497, 858);
EXECUTE PC_PERSONA.AD_Cliente (7375444248, 'C.E', 'Neala', 'Semaine', '9 Fairview Way', 'nsemaine14@phpbb.com', 'ingeniero', 9523460, 634);
EXECUTE PC_PERSONA.AD_Cliente (5426786465, 'C.C', 'Flori', 'Saiger', '7824 Manley Circle', 'fsaiger15@princeton.edu', 'médico', 3256832, 238);
EXECUTE PC_PERSONA.AD_Cliente (4434538701, 'C.C', 'Sharl', 'Pullar', '901 Stang Park', 'spullar16@thetimes.co.uk', 'artista', 8700952, 86);
EXECUTE PC_PERSONA.AD_Cliente (4966022282, 'C.C', 'Arny', 'McReidy', '6372 Doe Crossing Crossing', 'amcreidy17@cornell.edu', 'científico', 7336810, 446);
EXECUTE PC_PERSONA.AD_Cliente (2629167193, 'C.E', 'Lillis', 'Ransome', '96 8th Plaza', 'lransome18@eventbrite.com', 'profesor', 8386495, 135);
EXECUTE PC_PERSONA.AD_Cliente (5296480564, 'C.E', 'Shaina', 'Jealous', '85 Vermont Road', 'sjealous19@oracle.com', 'científico', 2743601, 54);
EXECUTE PC_PERSONA.AD_Cliente (7404679490, 'C.E', 'Berri', 'Furmenger', '8 Heffernan Avenue', 'bfurmenger1a@dropbox.com', 'cocinero', 1961228, 445);
EXECUTE PC_PERSONA.AD_Cliente (3287699897, 'C.C', 'Pepita', 'Szymanowicz', '4 Norway Maple Place', 'pszymanowicz1b@nih.gov', 'artista', 2614610, 305);
EXECUTE PC_PERSONA.AD_Cliente (6148269315, 'C.C', 'Jason', 'Mullally', '1 Truax Avenue', 'jmullally1c@mayoclinic.com', 'médico', 9139072, 931);
EXECUTE PC_PERSONA.AD_Cliente (8593562405, 'T.I', 'Craggy', 'Drewson', '3 Sutherland Point', 'cdrewson1d@soup.io', 'cocinero', 1093118, 558);
EXECUTE PC_PERSONA.AD_Cliente (6840514050, 'C.C', 'Ingamar', 'Stearley', '60 Scoville Trail', 'istearley1e@shareasale.com', 'atleta', 2834221, 52);
EXECUTE PC_PERSONA.AD_Cliente (2708838813, 'C.E', 'Siusan', 'MacCaffery', '22309 Lerdahl Way', 'smaccaffery1f@cbsnews.com', 'atleta', 9400086, 687);
EXECUTE PC_PERSONA.AD_Cliente (3325741829, 'C.E', 'Chaddy', 'Summerson', '6 Sundown Avenue', 'csummerson1g@loc.gov', 'cocinero', 4386671, 209);
EXECUTE PC_PERSONA.AD_Cliente (7518151065, 'C.E', 'Randall', 'Metheringham', '2087 Mifflin Alley', 'rmetheringham1h@go.com', 'científico', 7365894, 740);
EXECUTE PC_PERSONA.AD_Cliente (4491131280, 'T.I', 'Lothaire', 'Miroy', '569 Swallow Park', 'lmiroy1i@biblegateway.com', 'ingeniero', 241714, 825);
EXECUTE PC_PERSONA.AD_Cliente (8649241864, 'C.E', 'Erv', 'Volkers', '587 Arkansas Crossing', 'evolkers1j@businessinsider.com', 'atleta', 2402406, 268);
EXECUTE PC_PERSONA.AD_Cliente (6775257677, 'T.I', 'Pauly', 'Dorrian', '3576 Upham Terrace', 'pdorrian1k@usda.gov', 'músico', 9755926, 631);
EXECUTE PC_PERSONA.AD_Cliente (7800476854, 'T.I', 'Farris', 'Coule', '798 Steensland Junction', 'fcoule1l@whitehouse.gov', 'médico', 8785238, 191);
EXECUTE PC_PERSONA.AD_Cliente (4840077540, 'C.E', 'Dannie', 'Strudwick', '6 Troy Crossing', 'dstrudwick1m@cnet.com', 'escritor', 4318409, 758);
EXECUTE PC_PERSONA.AD_Cliente (4542810891, 'C.E', 'Tam', 'Olford', '1 Farragut Circle', 'tolford1n@cam.ac.uk', 'médico', 1350989, 604);
EXECUTE PC_PERSONA.AD_Cliente (9687807398, 'T.I', 'Leonidas', 'Sands', '67553 Logan Road', 'lsands1o@ed.gov', 'abogado', 8070609, 548);
EXECUTE PC_PERSONA.AD_Cliente (9745375906, 'C.E', 'Emerson', 'Este', '305 Nobel Terrace', 'eeste1p@nytimes.com', 'cocinero', 2680412, 500);
EXECUTE PC_PERSONA.AD_Cliente (5331712043, 'T.I', 'Cyrill', 'Cashford', '3009 Maple Hill', 'ccashford1q@fema.gov', 'artista', 555409, 108);
EXECUTE PC_PERSONA.AD_Cliente (5806987221, 'C.E', 'Keary', 'Ruggen', '5 Schurz Drive', 'kruggen1r@last.fm', 'médico', 2781632, 730);
EXECUTE PC_PERSONA.AD_Cliente (5587740841, 'T.I', 'Kaycee', 'Wilkie', '239 Schlimgen Avenue', 'kwilkie1s@etsy.com', 'músico', 4262010, 529);
EXECUTE PC_PERSONA.AD_Cliente (8865078381, 'C.E', 'Forbes', 'Jellico', '27855 Northland Circle', 'fjellico1t@abc.net.au', 'médico', 262367, 915);
EXECUTE PC_PERSONA.AD_Cliente (6375787339, 'T.I', 'Carmina', 'Schubert', '4 Fallview Alley', 'cschubert1u@shinystat.com', 'científico', 1271230, 102);
EXECUTE PC_PERSONA.AD_Cliente (1058390468, 'C.E', 'Pennie', 'Gedge', '12 Sloan Point', 'pgedge1v@1und1.de', 'atleta', 8503609, 490);
EXECUTE PC_PERSONA.AD_Cliente (1017627593, 'C.E', 'Larine', 'Muffen', '13768 Dixon Plaza', 'lmuffen1w@instagram.com', 'músico', 5555048, 427);
EXECUTE PC_PERSONA.AD_Cliente (6663381565, 'T.I', 'Emanuele', 'Poller', '728 Elka Terrace', 'epoller1x@pen.io', 'científico', 7727738, 315);
EXECUTE PC_PERSONA.AD_Cliente (8063327197, 'C.E', 'Shayna', 'Hayle', '734 Continental Pass', 'shayle1y@cam.ac.uk', 'artista', 5482227, 44);
EXECUTE PC_PERSONA.AD_Cliente (6187445500, 'T.I', 'Delinda', 'Snoddon', '32 Bashford Trail', 'dsnoddon1z@plala.or.jp', 'profesor', 621810, 15);
EXECUTE PC_PERSONA.AD_Cliente (5786162862, 'C.E', 'Meredith', 'Beecheno', '216 Shasta Parkway', 'mbeecheno20@umich.edu', 'escritor', 4283383, 182);
EXECUTE PC_PERSONA.AD_Cliente (5519418126, 'T.I', 'Rianon', 'Bourthoumieux', '08 Harbort Center', 'rbourthoumieux21@salon.com', 'escritor', 8241001, 27);
EXECUTE PC_PERSONA.AD_Cliente (9130086688, 'C.E', 'Barbara', 'Jagiello', '70160 Cardinal Place', 'bjagiello22@imgur.com', 'médico', 7101466, 488);
EXECUTE PC_PERSONA.AD_Cliente (4829931666, 'C.E', 'Michal', 'Dosdell', '4050 Mosinee Terrace', 'mdosdell23@hatena.ne.jp', 'artista', 198943, 166);
EXECUTE PC_PERSONA.AD_Cliente (8542358902, 'T.I', 'Tove', 'Physic', '217 Golden Leaf Court', 'tphysic24@storify.com', 'profesor', 5162512, 640);
EXECUTE PC_PERSONA.AD_Cliente (2822959087, 'T.I', 'Pauly', 'Foakes', '53 Ramsey Center', 'pfoakes25@barnesandnoble.com', 'ingeniero', 8001615, 735);
EXECUTE PC_PERSONA.AD_Cliente (6214420388, 'C.E', 'Reese', 'Maggill''Andreis', '106 Hoepker Place', 'rmaggillandreis26@sun.com', 'abogado', 7900599, 132);
EXECUTE PC_PERSONA.AD_Cliente (1234744036, 'C.C', 'Merry', 'Rex', '8204 Susan Way', 'mrex27@gravatar.com', 'ingeniero', 6751907, 514);
EXECUTE PC_PERSONA.AD_Cliente (3810306891, 'C.E', 'Koo', 'Guenther', '4098 Talmadge Lane', 'kguenther28@weibo.com', 'científico', 3692335, 74);
EXECUTE PC_PERSONA.AD_Cliente (591752918, 'T.I', 'Kris', 'Lingwood', '4 Miller Park', 'klingwood29@exblog.jp', 'ingeniero', 4588601, 790);
EXECUTE PC_PERSONA.AD_Cliente (9178171931, 'C.C', 'Kale', 'Roby', '4974 Namekagon Lane', 'kroby2a@constantcontact.com', 'ingeniero', 2768471, 107);
EXECUTE PC_PERSONA.AD_Cliente (1726673596, 'T.I', 'Glennis', 'Curror', '114 Dorton Crossing', 'gcurror2b@mapy.cz', 'cocinero', 4230078, 817);
EXECUTE PC_PERSONA.AD_Cliente (6849603782, 'C.C', 'Timmie', 'Wardesworth', '99338 Burrows Drive', 'twardesworth2c@google.it', 'científico', 8834188, 352);
EXECUTE PC_PERSONA.AD_Cliente (9314190573, 'C.C', 'Randy', 'Sailor', '29 Knutson Lane', 'rsailor2d@sfgate.com', 'músico', 55396, 362);
EXECUTE PC_PERSONA.AD_Cliente (161816194, 'C.C', 'Yvor', 'Lie', '73065 Daystar Junction', 'ylie2e@google.es', 'atleta', 1231801, 892);
EXECUTE PC_PERSONA.AD_Cliente (1409791996, 'C.E', 'Pippa', 'Wilber', '54707 Arapahoe Point', 'pwilber2f@shareasale.com', 'escritor', 3979051, 517);
EXECUTE PC_PERSONA.AD_Cliente (5017491644, 'T.I', 'Frannie', 'Piecha', '331 Thompson Hill', 'fpiecha2g@ox.ac.uk', 'profesor', 4080144, 14);
EXECUTE PC_PERSONA.AD_Cliente (2168745003, 'C.E', 'Miguel', 'Underwood', '45815 Sycamore Road', 'munderwood2h@google.com', 'abogado', 148046, 595);
EXECUTE PC_PERSONA.AD_Cliente (6659947066, 'C.C', 'Audra', 'Powrie', '429 Springview Court', 'apowrie2i@list-manage.com', 'músico', 1426268, 851);
EXECUTE PC_PERSONA.AD_Cliente (4426446880, 'T.I', 'Melisa', 'Stepto', '4 Grover Crossing', 'mstepto2j@ovh.net', 'escritor', 4915898, 246);
EXECUTE PC_PERSONA.AD_Cliente (169343544, 'C.C', 'Judie', 'Garvey', '53 Ludington Parkway', 'jgarvey2k@qq.com', 'escritor', 6833389, 925);
EXECUTE PC_PERSONA.AD_Cliente (6073570095, 'T.I', 'Hamil', 'Marchetti', '36130 Saint Paul Alley', 'hmarchetti2l@sun.com', 'escritor', 4955267, 495);
EXECUTE PC_PERSONA.AD_Cliente (3484889862, 'T.I', 'Ulberto', 'Hebbs', '2 Ryan Hill', 'uhebbs2m@php.net', 'abogado', 256229, 730);
EXECUTE PC_PERSONA.AD_Cliente (3590044574, 'C.C', 'Cathleen', 'Elgar', '75 Dorton Way', 'celgar2n@spotify.com', 'abogado', 5230959, 893);
EXECUTE PC_PERSONA.AD_Cliente (1905760362, 'C.E', 'Anissa', 'Thraves', '383 Hayes Street', 'athraves2o@cdc.gov', 'cocinero', 991813, 604);
EXECUTE PC_PERSONA.AD_Cliente (8105126336, 'C.C', 'Hastings', 'Ranyard', '0357 Canary Junction', 'hranyard2p@hugedomains.com', 'cocinero', 2247785, 446);
EXECUTE PC_PERSONA.AD_Cliente (2131955363, 'T.I', 'Dewitt', 'Jasiak', '21 Granby Parkway', 'djasiak2q@gmpg.org', 'artista', 9777680, 282);

--Insert Telefonos Clientes
EXECUTE PC_PERSONA.AD_Telefono (2131955363, 3147891234);
EXECUTE PC_PERSONA.AD_Telefono (8105126336, 3508964589);

--Insert Empleados
EXECUTE PC_PERSONA.AD_Empleado (4185057482, 'C.C', 'Bliss', 'Cuesta', '9 Hanover Parkway', 'bcuesta0@army.mil', 'H', 'D', 'Administrador', 3595747);
EXECUTE PC_PERSONA.AD_Empleado (2219724226, 'C.C', 'Agata', 'Duckinfield', '5 Arrowood Center', 'aduckinfield1@businesswire.com', 'H', 'D', 'Vendedor', 2489028);
EXECUTE PC_PERSONA.AD_Empleado (6001040089, 'C.E', 'Erik', 'Maultby', '886 Sunfield Street', 'emaultby2@delicious.com', 'H', 'C', 'Macanico', 4550990);
EXECUTE PC_PERSONA.AD_Empleado (568885108, 'C.E', 'Christye', 'Tampion', '506 Cherokee Junction', 'ctampion3@squarespace.com', 'O', 'D', 'Administrador', 2247684);
EXECUTE PC_PERSONA.AD_Empleado (17721119, 'T.I', 'Marlyn', 'Godley', '3 Burrows Place', 'mgodley4@accuweather.com', 'H', 'D', 'Administrador', 3942277);
EXECUTE PC_PERSONA.AD_Empleado (5893009909, 'T.I', 'Freddy', 'Pollicote', '39781 Meadow Valley Circle', 'fpollicote5@princeton.edu', 'H', 'U', 'Vendedor', 3086920);
EXECUTE PC_PERSONA.AD_Empleado (8685474133, 'C.C', 'Brietta', 'Staniland', '66163 Tennyson Place', 'bstaniland6@yelp.com', 'H', 'U', 'Macanico', 1986831);
EXECUTE PC_PERSONA.AD_Empleado (2606111723, 'T.I', 'Marsha', 'Hanbidge', '890 Blue Bill Park Street', 'mhanbidge7@opera.com', 'M', 'D', 'Vendedor', 4386080);
EXECUTE PC_PERSONA.AD_Empleado (9609553542, 'C.E', 'Caresse', 'Watt', '826 Nancy Center', 'cwatt8@g.co', 'O', 'U', 'Vendedor', 3171756);
EXECUTE PC_PERSONA.AD_Empleado (9399649981, 'C.C', 'Ardelis', 'Gossage', '847 Charing Cross Road', 'agossage9@geocities.jp', 'H', 'U', 'Macanico', 4820509);

--Insert Telefonos Empleados
EXECUTE PC_PERSONA.AD_Telefono (4185057482, 314569745);
EXECUTE PC_PERSONA.AD_Telefono (2219724226, 3145897487);
EXECUTE PC_PERSONA.AD_Telefono (6001040089, 3149878958);
EXECUTE PC_PERSONA.AD_Telefono (568885108,  3105896985);
EXECUTE PC_PERSONA.AD_Telefono (17721119,   3145896985);
EXECUTE PC_PERSONA.AD_Telefono (5893009909, 3115896987);
EXECUTE PC_PERSONA.AD_Telefono (8685474133, 3568968745);
EXECUTE PC_PERSONA.AD_Telefono (2606111723, 3106981234);
EXECUTE PC_PERSONA.AD_Telefono (9609553542, 3145879632);
EXECUTE PC_PERSONA.AD_Telefono (9399649981, 3145691234);

--Insert Proveedores
EXECUTE PC_COMPRAS.AD_Proveedor ('HONDA', 'CARRERA 7 # 89-69', 'VENTASHONDA@HONDA.COM', 'Carlos Arturo Telefono: 31458964785');
EXECUTE PC_COMPRAS.AD_Proveedor ('BMW', 'CARRERA 14 # 89-17', 'VENTASBMW@BMW.COM', 'Carlos Julio Telefono: 3145691234');
EXECUTE PC_COMPRAS.AD_Proveedor ('DUCATI', 'CALLE 14 # 89-39', 'VENTASDUCATI@DUCATI.COM', 'Alfonso Julio Telefono: 3106981234');
EXECUTE PC_COMPRAS.AD_Proveedor ('HERO MOTOS', 'CALLE 14 # 90-69', 'VENTASHERO@HERO.COM', 'Julio Telefono: 3145896985');
EXECUTE PC_COMPRAS.AD_Proveedor ('KAWASAKI', 'CALLE 1 # 90-9', 'VENTASKAWASAKI@KAWASAKI.COM', 'Marcos Telefono: 3105896985');
EXECUTE PC_COMPRAS.AD_Proveedor ('PULSAR', 'CALLE 41 # 90-12', 'VENTASPULSAR@PULSAR.COM', 'Marcos Telefono: 3105698775');
EXECUTE PC_COMPRAS.AD_Proveedor ('SUZUKI', 'CALLE 41 # 90-47', 'VENTASSUZUKI@SUZUKI.COM', 'Cristina Ramirez Telefono: 3101698745');
EXECUTE PC_COMPRAS.AD_Proveedor ('YAMAHA', 'CALLE 80 # 97-65', 'VENTASYAMAHA@YAMAHA.COM', 'Cristina Ramirez Telefono: 31055698745');
EXECUTE PC_COMPRAS.AD_Proveedor ('CF MOTO', 'CALLE 80 # 97-65', 'VENTASCF@CF.COM', 'Cristina Cortes Telefono: 3105598745');
EXECUTE PC_COMPRAS.AD_Proveedor ('HARLEY DAVIDSON', 'CALLE 80 # 97-65', 'VENTASHARLEY@HARLEY.COM', 'Cristina Tarazona Telefono: 3005598745');
EXECUTE PC_COMPRAS.AD_Proveedor ('BENELLI', 'CALLE 80 # 97-65', 'VENTASBENELLI@BENELLI.COM', 'Cristina Tarazona Telefono: 3005598745');

--Insert Telefonos Proveedores
EXECUTE PC_COMPRAS.AD_telefono (1, 31458964785);
EXECUTE PC_COMPRAS.AD_telefono (2, 3145691234);
EXECUTE PC_COMPRAS.AD_telefono (3, 3106981234);
EXECUTE PC_COMPRAS.AD_telefono (4, 3145896985);
EXECUTE PC_COMPRAS.AD_telefono (5, 3105896985);
EXECUTE PC_COMPRAS.AD_telefono (6, 31458964785);
EXECUTE PC_COMPRAS.AD_telefono (7, 3101698745);
EXECUTE PC_COMPRAS.AD_telefono (8, 3105598745);
EXECUTE PC_COMPRAS.AD_telefono (9, 3005598745);
EXECUTE PC_COMPRAS.AD_telefono (10, 3005598745);

--Insert Repuestos
EXECUTE PC_PRODUCTOS.AD_Repuestos('R1','Llanta Honda XR 150L',250000, 0, 'R', 'D', 'Llanta', 'Llanta para moto Honda XR 150L');
EXECUTE PC_PRODUCTOS.AD_Repuestos('R2','Llanta BMW G 310 R',169000, 0, 'R', 'D', 'Llanta', 'Llanta para moto BMW G 310 R');
EXECUTE PC_PRODUCTOS.AD_Repuestos('R3','Llanta Ducati Monster 797',560000, 0, 'R', 'D', 'Llanta', 'Llanta para moto Ducati Monster 797');
EXECUTE PC_PRODUCTOS.AD_Repuestos('R4','Llanta Hero Motocorp Passion Pro',980000, 0, 'R', 'D', 'Llanta', 'Llanta para moto Hero Motocorp Passion Pro');
EXECUTE PC_PRODUCTOS.AD_Repuestos('R5','Llanta para moto Kawasaki Ninja 300',350000, 0, 'R', 'D', 'Llanta', 'Llanta para moto Kawasaki Ninja 300');
EXECUTE PC_PRODUCTOS.AD_Repuestos('R6','Llanta para moto Pulsar NS 200',240000, 0, 'R', 'D', 'Llanta', 'Llanta para moto Pulsar NS 200');
EXECUTE PC_PRODUCTOS.AD_Repuestos('R7','Llanta para moto Suzuki Gixxer SF',458000, 0, 'R', 'D', 'Llanta', 'Llanta para moto Suzuki Gixxer SF');
EXECUTE PC_PRODUCTOS.AD_Repuestos('R8','Llanta para moto Yamaha FZ25',499000, 0, 'R', 'D', 'Llanta', 'Llanta para moto Yamaha FZ25');
EXECUTE PC_PRODUCTOS.AD_Repuestos('R9','Llanta para moto CF Moto 400 NK',1250000, 0, 'R', 'D', 'Llanta', 'Llanta para moto CF Moto 400 NK');
EXECUTE PC_PRODUCTOS.AD_Repuestos('R10','Llanta para moto Harley Davidson Street 750',2600000, 0, 'R', 'D', 'Llanta', 'Llanta para moto Harley Davidson Street 750');

-- Insert Motos
EXECUTE PC_PRODUCTOS.AD_Motos('M1', 'Honda XR 150L', 7500000, 0, 'M', 'D', 'Honda', 'XR 150L', TO_DATE('2019-01-01', 'YYYY-MM-DD'), 'Rojo', '150', 'Moto Honda XR 150L');
EXECUTE PC_PRODUCTOS.AD_Motos('M2', 'BMW G 310 R', 25000000, 0, 'M', 'D', 'BMW', 'G 310 R', TO_DATE('2023-01-01', 'YYYY-MM-DD'), 'Rojo', '310', 'Moto BMW G 310 R');
EXECUTE PC_PRODUCTOS.AD_Motos('M3', 'Ducati Monster 797', 78000000, 0, 'M', 'D', 'Ducati', 'Monster 797', TO_DATE('2022-01-01', 'YYYY-MM-DD'), 'Rojo', '797', 'Moto Ducati Monster 797');
EXECUTE PC_PRODUCTOS.AD_Motos('M4', 'Hero Motocorp Passion Pro', 32000000, 0, 'M', 'D', 'Hero Motocorp', 'Passion Pro', TO_DATE('2021-01-01', 'YYYY-MM-DD'), 'Rojo', '150', 'Moto Hero Motocorp Passion Pro');
EXECUTE PC_PRODUCTOS.AD_Motos('M5', 'Kawasaki Ninja 300', 14000000, 0, 'M', 'D', 'Kawasaki', 'Ninja 300', TO_DATE('2020-01-01', 'YYYY-MM-DD'), 'Rojo', '300', 'Moto Kawasaki Ninja 300');
EXECUTE PC_PRODUCTOS.AD_Motos('M6', 'Pulsar NS 200', 12000000, 0, 'M', 'D', 'Pulsar', 'NS 200', TO_DATE('2020-01-01', 'YYYY-MM-DD'), 'Rojo', '200', 'Moto Pulsar NS 200');
EXECUTE PC_PRODUCTOS.AD_Motos('M7', 'Suzuki Gixxer SF', 15000000, 0, 'M', 'D', 'Suzuki', 'Gixxer SF', TO_DATE('2022-01-01', 'YYYY-MM-DD'), 'Rojo', '150', 'Moto Suzuki Gixxer SF');
EXECUTE PC_PRODUCTOS.AD_Motos('M8', 'Yamaha FZ25', 15900000, 0, 'M', 'D', 'Yamaha', 'FZ25', TO_DATE('2018-01-01', 'YYYY-MM-DD'), 'Rojo', '250', 'Moto Yamaha FZ25');
EXECUTE PC_PRODUCTOS.AD_Motos('M9', 'CF Moto 400 NK', 45000000, 0, 'M', 'D', 'CF Moto', '400 NK', TO_DATE('2019-01-01', 'YYYY-MM-DD'), 'Rojo', '400', 'Moto CF Moto 400 NK');
EXECUTE PC_PRODUCTOS.AD_Motos('M10', 'Harley Davidson Street 750', 49000000, 0, 'M', 'D', 'Harley Davidson', 'Street 750', TO_DATE('2023-01-01', 'YYYY-MM-DD'), 'Rojo', '750', 'Moto Harley Davidson Street 750');

-- Insert Accesorios
EXECUTE PC_PRODUCTOS.AD_Accesorios('A1', 'Casco Honda XR 150L', 250000, 0, 'A', 'D', 'Casco para moto Honda XR 150L');
EXECUTE PC_PRODUCTOS.AD_Accesorios('A2', 'Casco BMW G 310 R', 169000, 0, 'A', 'D', 'Casco para moto BMW G 310 R');
EXECUTE PC_PRODUCTOS.AD_Accesorios('A3', 'Casco Ducati Monster 797', 560000, 0, 'A', 'D', 'Casco para moto Ducati Monster 797');
EXECUTE PC_PRODUCTOS.AD_Accesorios('A4', 'Casco Hero Motocorp Passion Pro', 980000, 0, 'A', 'D', 'Casco para moto Hero Motocorp Passion Pro');
EXECUTE PC_PRODUCTOS.AD_Accesorios('A5', 'Casco para moto Kawasaki Ninja 300', 350000, 0, 'A', 'D', 'Casco para moto Kawasaki Ninja 300');
EXECUTE PC_PRODUCTOS.AD_Accesorios('A6', 'Casco para moto Pulsar NS 200', 240000, 0, 'A', 'D', 'Casco para moto Pulsar NS 200');
EXECUTE PC_PRODUCTOS.AD_Accesorios('A7', 'Casco para moto Suzuki Gixxer SF', 458000, 0, 'A', 'D', 'Casco para moto Suzuki Gixxer SF');
EXECUTE PC_PRODUCTOS.AD_Accesorios('A8', 'Casco para moto Yamaha FZ25', 499000, 0, 'A', 'D', 'Casco para moto Yamaha FZ25');
EXECUTE PC_PRODUCTOS.AD_Accesorios('A9', 'Casco para moto CF Moto 400 NK', 1250000, 0, 'A', 'D', 'A para moto CF Moto 400 NK');
EXECUTE PC_PRODUCTOS.AD_Accesorios('A10', 'Casco para moto Harley Davidson Street 750', 2600000, 0, 'A', 'D', 'Casco para moto Harley Davidson Street 750');

--Insert Compras
--Se separan por porcedimientos para que no se ejecute todo el script de una vez

--Compra Repuesots

BEGIN
    --Compra
    PC_COMPRAS.AD_Compra(1, 4185057482, 'A', 'Compra de repuestos bajo cilindraje');
    --DetallesComptas
    PC_COMPRAS.AD_DetalleCompra(SEQ_idCompra.CURRVAL, 'R1', 8, 250000);
    PC_COMPRAS.AD_DetalleCompra(SEQ_idCompra.CURRVAL, 'R7', 2, 458000);
    PC_COMPRAS.AD_DetalleCompra(SEQ_idCompra.CURRVAL, 'R10', 3, 2600000);
    PC_COMPRAS.AD_DetalleCompra(SEQ_idCompra.CURRVAL, 'R4', 4, 980000);
END;
/

BEGIN
    --Compra
    PC_COMPRAS.AD_Compra(2, 9609553542, 'A', 'Compra de Repuestos Alto cilindraje');
    --DetallesComptas
    PC_COMPRAS.AD_DetalleCompra(SEQ_idCompra.CURRVAL, 'R2', 8, 169000);
    PC_COMPRAS.AD_DetalleCompra(SEQ_idCompra.CURRVAL, 'R3', 8, 560000);
    PC_COMPRAS.AD_DetalleCompra(SEQ_idCompra.CURRVAL, 'R4', 8, 980000);
    PC_COMPRAS.AD_DetalleCompra(SEQ_idCompra.CURRVAL, 'R5', 4, 350000);
    PC_COMPRAS.AD_DetalleCompra(SEQ_idCompra.CURRVAL, 'R6', 2, 240000);
    PC_COMPRAS.AD_DetalleCompra(SEQ_idCompra.CURRVAL, 'R9', 3, 1250000);
END;
/

--Compra motos

BEGIN
    --Compra
    PC_COMPRAS.AD_Compra(3, 2219724226, 'A', 'Compra de Motos');
    --DetallesComptas
    PC_COMPRAS.AD_DetalleCompra(SEQ_idCompra.CURRVAL, 'M1', 5, 7500000);
    PC_COMPRAS.AD_DetalleCompra(SEQ_idCompra.CURRVAL, 'M2', 4, 25000000);
    PC_COMPRAS.AD_DetalleCompra(SEQ_idCompra.CURRVAL, 'M3', 6, 78000000);
    PC_COMPRAS.AD_DetalleCompra(SEQ_idCompra.CURRVAL, 'M4', 8, 32000000);
END;
/

BEGIN
    --Compra
    PC_COMPRAS.AD_Compra(4, 6001040089, 'A', 'Compra de Motos Gran cantidad');
    --DetallesComptas
    PC_COMPRAS.AD_DetalleCompra(SEQ_idCompra.CURRVAL, 'M5', 5, 14000000);
    PC_COMPRAS.AD_DetalleCompra(SEQ_idCompra.CURRVAL, 'M6', 10, 12000000);
    PC_COMPRAS.AD_DetalleCompra(SEQ_idCompra.CURRVAL, 'M7', 6, 15000000);
    PC_COMPRAS.AD_DetalleCompra(SEQ_idCompra.CURRVAL, 'M8', 8, 15900000);
    PC_COMPRAS.AD_DetalleCompra(SEQ_idCompra.CURRVAL, 'M9', 8, 45000000);
    PC_COMPRAS.AD_DetalleCompra(SEQ_idCompra.CURRVAL, 'M10', 8, 49000000);
END;
/

-- Compra Accesorios

BEGIN
    --Compra
    PC_COMPRAS.AD_Compra(5, 4185057482, 'A', 'Compra de Accesorios');
    --DetallesComptas
    PC_COMPRAS.AD_DetalleCompra(SEQ_idCompra.CURRVAL, 'A1', 8, 250000);
    PC_COMPRAS.AD_DetalleCompra(SEQ_idCompra.CURRVAL, 'A7', 2, 458000);
    PC_COMPRAS.AD_DetalleCompra(SEQ_idCompra.CURRVAL, 'A10', 3, 2600000);
    PC_COMPRAS.AD_DetalleCompra(SEQ_idCompra.CURRVAL, 'A4', 4, 980000);
END;
/

BEGIN
    --Compra
    PC_COMPRAS.AD_Compra(6, 9609553542, 'A', 'Compra de Accesorios Alto cilindraje');
    --DetallesComptas
    PC_COMPRAS.AD_DetalleCompra(SEQ_idCompra.CURRVAL, 'A2', 8, 169000);
    PC_COMPRAS.AD_DetalleCompra(SEQ_idCompra.CURRVAL, 'A3', 8, 560000);
    PC_COMPRAS.AD_DetalleCompra(SEQ_idCompra.CURRVAL, 'A4', 8, 980000);
    PC_COMPRAS.AD_DetalleCompra(SEQ_idCompra.CURRVAL, 'A5', 4, 350000);
    PC_COMPRAS.AD_DetalleCompra(SEQ_idCompra.CURRVAL, 'A6', 2, 240000);
    PC_COMPRAS.AD_DetalleCompra(SEQ_idCompra.CURRVAL, 'A9', 3, 1250000);
END;
/

--Insert Ventas

--Venta Repuestos

BEGIN
    --Venta
    PC_VENTAS.AD_Venta(4185057482, 5587740841, 'Venta de repuestos bajo cilindraje', 'A');
    --DetallesVentas
    PC_VENTAS.AD_DetalleVenta(SEQ_idVenta.CURRVAL, 'R1', 4, 250000);
    PC_VENTAS.AD_DetalleVenta(SEQ_idVenta.CURRVAL, 'R7', 2, 458000);
    PC_VENTAS.AD_DetalleVenta(SEQ_idVenta.CURRVAL, 'R10', 3, 2600000);
    PC_VENTAS.AD_DetalleVenta(SEQ_idVenta.CURRVAL, 'R4', 4, 980000);
END;
/

BEGIN
    --Venta
    PC_VENTAS.AD_Venta(9609553542, 6375787339, 'Venta de Repuestos Alto cilindraje', 'A');
    --DetallesVentas
    PC_VENTAS.AD_DetalleVenta(SEQ_idVenta.CURRVAL, 'R2', 8, 169000);
    PC_VENTAS.AD_DetalleVenta(SEQ_idVenta.CURRVAL, 'R3', 8, 560000);
    PC_VENTAS.AD_DetalleVenta(SEQ_idVenta.CURRVAL, 'R4', 8, 980000);
    PC_VENTAS.AD_DetalleVenta(SEQ_idVenta.CURRVAL, 'R5', 4, 350000);
    PC_VENTAS.AD_DetalleVenta(SEQ_idVenta.CURRVAL, 'R6', 2, 240000);
    PC_VENTAS.AD_DetalleVenta(SEQ_idVenta.CURRVAL, 'R9', 3, 1250000);
END;

--Venta motos

BEGIN
    --Venta
    PC_VENTAS.AD_Venta(6001040089, 3484889862, 'Venta de Motos', 'A');
    --DetallesVentas
    PC_VENTAS.AD_DetalleVenta(SEQ_idVenta.CURRVAL, 'M1', 3, 7500000);
    PC_VENTAS.AD_DetalleVenta(SEQ_idVenta.CURRVAL, 'M2', 2, 25000000);
    PC_VENTAS.AD_DetalleVenta(SEQ_idVenta.CURRVAL, 'M3', 2, 78000000);
    PC_VENTAS.AD_DetalleVenta(SEQ_idVenta.CURRVAL, 'M4', 4, 32000000);
END;
/

BEGIN
    --Venta
    PC_VENTAS.AD_Venta(6001040089, 5017491644, 'Venta de Motos Gran cantidad', 'A');
    --DetallesVentas
    PC_VENTAS.AD_DetalleVenta(SEQ_idVenta.CURRVAL, 'M5', 5, 14000000);
    PC_VENTAS.AD_DetalleVenta(SEQ_idVenta.CURRVAL, 'M6', 10, 12000000);
    PC_VENTAS.AD_DetalleVenta(SEQ_idVenta.CURRVAL, 'M7', 6, 15000000);
    PC_VENTAS.AD_DetalleVenta(SEQ_idVenta.CURRVAL, 'M8', 8, 15900000);
    PC_VENTAS.AD_DetalleVenta(SEQ_idVenta.CURRVAL, 'M9', 8, 45000000);
    PC_VENTAS.AD_DetalleVenta(SEQ_idVenta.CURRVAL, 'M10', 8, 49000000);
END;
/

