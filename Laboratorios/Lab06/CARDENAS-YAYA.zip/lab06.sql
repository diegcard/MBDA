CREATE TABLE personas(
    id NUMBER(9) NOT NULL,
    tipo VARCHAR2(10) NOT NULL,
    numero NUMBER(11)NOT NULL,
    nombre VARCHAR2(50)NOT NULL,
    registro DATE NOT NULL,
    celular NUMBER(10)NOT NULL,
    correo VARCHAR2(80) NOT NULL
);

CREATE TABLE conductores(
    idConductor NUMBER(9) NOT NULL,
    licencia VARCHAR2(10) NOT NULL,
    fechaNacimiento DATE NOT NULL,
    estrellas NUMBER(1) NOT NULL,
    estado VARCHAR2(10) NOT NULL
);

CREATE TABLE clientes(
    idCliente NUMBER(9) NOT NULL,
    idioma VARCHAR2(10) NOT NULL
);

CREATE TABLE vehiculos(
    idConductor NUMBER(9) NOT NULL,
    placa VARCHAR2(30) NOT NULL,
    a_o VARCHAR2(10)NOT NULL,
    tipo CHAR(1) NOT NULL,
    estado VARCHAR2(10) NOT NULL,
    puertas NUMBER(1) NULL,
    pasajeros NUMBER(1) NULL,
    carga NUMBER(5) NULL
);

CREATE TABLE tarjetasClientes(
    idCliente NUMBER(9) NOT NULL,
    numeroT NUMBER(15) NOT NULL
);

CREATE TABLE tarjetas(
    numero NUMBER(15) NOT NULL,
    entidad VARCHAR2(10)NOT NULL,
    vencimiento DATE NOT NULL
);

CREATE TABLE solicitudes(
    idCliente NUMBER(9) NOT NULL,
    codigo NUMBER(9) NOT NULL,
    fechaCreacion DATE NOT NULL,
    fechaViaje DATE NULL,
    plataforma CHAR(1) NOT NULL,
    precio FLOAT NULL,
    estado VARCHAR2(10) NOT NULL,
    ubicacionInicial NUMBER(11) NOT NULL,
    ubicacionFinal NUMBER(11) NOT NULL
);

CREATE TABLE requerimientos(
    info VARCHAR2(50) NULL,
    idSolicitud NUMBER(9) NOT NULL
);

CREATE TABLE posiciones(
    ubicacion NUMBER(11) NOT NULL,
    latitud FLOAT NOT NULL,
    longitud FLOAT NOT NULL
);

CREATE TABLE pqrs(
    ticked VARCHAR2(13) NOT NULL,
    codigoSolicitud NUMBER(9) NOT NULL,
    radicacion DATE NOT NULL,
    cierre DATE NULL,
    descripcion XMLTYPE NULL,
    tipo CHAR(1)NOT NULL,
    estado VARCHAR2(10) NOT NULL
);

CREATE TABLE anexos(
    idAnexo NUMBER(11) NOT NULL,
    idTicked VARCHAR2(13) NOT NULL,
    nombre VARCHAR2(20) NOT NULL,
    url VARCHAR2(50) NOT NULL
);

CREATE TABLE pqrsrespuestas(
	idTicked VARCHAR2(13) NOT NULL,
	fecha DATE NOT NULL,
	descripcion VARCHAR2(50) NOT NULL,
	nombre VARCHAR2(20) NOT NULL,
	correo VARCHAR2(80) NOT NULL,
	comentario VARCHAR2(20) NULL,
	evaluacion VARCHAR2(20) NULL
);

/*---------------------------------------------CICLO 1: Atributos---------------------------------------------*/

/*------------Restricciones CHECK para la tabla personas------------*/
/* Verifica que el atributo 'correo' cumple con un patron especifico de direccion de correo electronico */
ALTER TABLE personas ADD CONSTRAINT chk_personas_correo CHECK (REGEXP_LIKE(correo, '.*@.*'));
/* Verifica que el atributo 'tipo' contenga uno de los tipos de documentos especificados */
ALTER TABLE personas ADD CONSTRAINT chk_personas_tipo_documento CHECK (tipo IN ('CC', 'TI', 'RC', 'CE', 'CI', 'DNI'));


/*------------Restricciones CHECK para la tabla vehiculos------------*/
/* Verifica que el atributo 'a_o' sea un anio de 4 digitos entre 1900 y 2100 */
ALTER TABLE vehiculos ADD CONSTRAINT chk_vehiculos_a_o CHECK (LENGTH(a_o) = 4 AND TO_NUMBER(a_o) BETWEEN 1900 AND 2100);
/* Verifica que el atributo 'tipo' contenga uno de los tipos de vehiculos especificados ('M'(Moto), 'C'(Camioneta), 'c'(Carro)) */
ALTER TABLE vehiculos ADD CONSTRAINT chk_vehiculos_tipo CHECK (tipo IN ('M', 'C', 'c'));
/* Verifica que el atributo 'estado' contenga uno de los estados especificados ('Activo', 'Pendiente') */
ALTER TABLE vehiculos ADD CONSTRAINT chk_vehiculos_estado CHECK (estado IN ('Activo', 'Pendiente'));
/* Verifica que el atributo 'puertas' este en el rango de 0 a 4 */
ALTER TABLE vehiculos ADD CONSTRAINT chk_vehiculos_puertas CHECK (puertas >= 0 AND puertas <= 4); 
/* Verifica que el atributo 'pasajeros' sea igual o mayor que 0 */
ALTER TABLE vehiculos ADD CONSTRAINT chk_vehiculos_pasajeros CHECK (pasajeros >= 0);
/* Verifica que el atributo 'carga' cumpla con reglas especificas dependiendo del tipo de vehiculo:
   - Si el tipo no es 'c', entonces 'carga' debe ser NULL.
   - Si el tipo es 'C', entonces 'carga' no debe ser NULL y debe ser igual o mayor que 0. */
ALTER TABLE vehiculos ADD CONSTRAINT chk_vehiculos_carga CHECK ((tipo != 'c' AND carga IS NULL) OR (tipo = 'C' AND carga IS NOT NULL AND carga >= 0));


/*------------Restriccion CHECK para la tabla conductores------------*/
/* Verifica que el atributo 'estrellas' este en el rango de 1 a 5, lo que indica la calificacion de estrellas para los conductores. */
ALTER TABLE conductores ADD CONSTRAINT chk_conductores_estrellas CHECK (estrellas >= 1 AND estrellas <= 5);
/*Verifica que el estado del conductor sea Activo, Inactivo, Retirado u Ocupado */
ALTER TABLE conductores ADD CONSTRAINT chk_conductores_estado CHECK (estado IN ('Activo', 'Inactivo', 'Retirado', 'Ocupado'));


/*------------Restriccion CHECK para la tabla anexos------------*/
ALTER TABLE anexos ADD CONSTRAINT chk_anexos_url CHECK (SUBSTR(url, 1, 8) = 'https://');
ALTER TABLE anexos ADD CONSTRAINT chk__anexos_nombre CHECK (REGEXP_LIKE(nombre, 'Peticion|Queja|Reclamo|Sugerencia'));


/*------------Restriccion CHECK para la tabla pqrsrespuestas------------*/
/* Verifica que el atributo evaluacion se encuentre entre 1 y 5 */
ALTER TABLE pqrsrespuestas ADD CONSTRAINT chk_pqrsrespuestas_evaluacion CHECK (evaluacion BETWEEN 1 AND 5);
/* Verifica que el atributo 'correo' cumple con un patron especifico de direccion de correo electronico */
ALTER TABLE personas ADD CONSTRAINT chk_pqrsrespuestas_correo CHECK (REGEXP_LIKE(correo, '.*@.*'));


/*------------Restricciones CHECK para la tabla solicitudes------------*/
/* Verifica que el atributo 'plataforma' contenga uno de los valores permitidos ('W' o 'A'), que probablemente representen diferentes plataformas de origen. */
ALTER TABLE solicitudes ADD CONSTRAINT chk_solicitudes_plataforma CHECK (plataforma IN ('W', 'A'));
/* Verifica que el atributo 'estado' contenga uno de los valores permitidos ('Pendiente' o 'Asignada', 'Cancelada'), que indican el estado de la solicitud. */
ALTER TABLE solicitudes ADD CONSTRAINT chk_solicitudes_estado CHECK (estado IN ('Pendiente', 'Asignada', 'Cancelada'));


/*------------Restricciones CHECK para la tabla clientes------------*/
/* Verifica que el atributo 'idioma' contenga uno de los idiomas permitidos ('Espaniol', 'Ingles', 'Frances', 'Aleman', 'Italiano', 'Portugues', 'Chino', 'Japones', 'Ruso', 'Arabe', 'Otros'). Esto asegura que el idioma registrado este dentro de la lista de opciones validas. */
ALTER TABLE clientes ADD CONSTRAINT chk_clientes_idioma CHECK (idioma IN ('Espaniol', 'Ingles', 'Frances', 'Aleman', 'Italiano', 'Portugues', 'Chino', 'Japones', 'Ruso', 'Arabe', 'Otros'));


/*------------Restricciones CHECK para la tabla pqrs------------*/
/*   */
//descripcion 
/* Verifica que el atributo 'ticked' siga un patron especifico que empiece con 'PQRS' seguido de 12 digitos. Esto suele ser un numero de seguimiento o identificador unico. */
ALTER TABLE pqrs ADD CONSTRAINT chk_pqrs_ticked CHECK (REGEXP_LIKE(ticked, '^[PQRS][0-9]{12}$'));
/* Verifica que el atributo 'tipo' contenga uno de los valores permitidos ('P', 'Q', 'R', 'S'), que representan el tipo de PQRS (Peticiones, Quejas, Reclamos o Sugerencias). */
ALTER TABLE pqrs ADD CONSTRAINT chk_pqrs_tipo CHECK (tipo IN ('P', 'Q', 'R', 'S'));
/* Verifica que el atributo 'estado' contenga uno de los valores permitidos ('Abierto', 'Cerrado', 'Rechazado'), que reflejan el estado actual del PQRS. */
ALTER TABLE pqrs ADD CONSTRAINT chk_pqrs_estado CHECK (estado IN ('Abierto', 'Cerrado', 'Rechazado'));

/*---------------------------------------------CICLO 1: Primarias--------------------------------------------*/
ALTER TABLE personas ADD CONSTRAINT pk_personas_id PRIMARY KEY (id);
ALTER TABLE vehiculos ADD CONSTRAINT pk_vehiculos_placa PRIMARY KEY(placa);
ALTER TABLE conductores ADD CONSTRAINT pk_conductores_idConductor PRIMARY KEY(idConductor);
ALTER TABLE tarjetas ADD CONSTRAINT pk_tarjetas_numero PRIMARY KEY(numero);
ALTER TABLE tarjetasClientes ADD CONSTRAINT pk_tarjetasClientes_idCliente_numeroT PRIMARY KEY(idCliente, numeroT);
ALTER TABLE posiciones ADD CONSTRAINT pk_posiciones_ubicacion PRIMARY KEY(ubicacion);
ALTER TABLE anexos ADD CONSTRAINT pk_anexos_idAnexo PRIMARY KEY(idAnexo);
ALTER TABLE pqrsrespuestas ADD CONSTRAINT pk_pqrsrespuestas_idTicked PRIMARY KEY(idTicked);
ALTER TABLE pqrs ADD CONSTRAINT pk_pqrs_ticked PRIMARY KEY(ticked);
ALTER TABLE requerimientos ADD CONSTRAINT pk_requerimientos_idSolicitud PRIMARY KEY(idSolicitud);
ALTER TABLE solicitudes ADD CONSTRAINT pk_solicitudes_codigo PRIMARY KEY(codigo);
ALTER TABLE clientes ADD CONSTRAINT pk_clientes_idCliente PRIMARY KEY(idCliente);

/*---------------------------------------------CICLO 1: Unicas--------------------------------------------*/
ALTER TABLE personas ADD CONSTRAINT uk_personas_tipo_numero UNIQUE (tipo, numero);
ALTER TABLE personas DROP CONSTRAINT uk_personas_tipo_numero;
ALTER TABLE anexos ADD CONSTRAINT uk_anexos_url UNIQUE (url);

/*---------------------------------------------CICLO 1: Foraneas---------------------------------------------*/
ALTER TABLE vehiculos ADD CONSTRAINT fk_vehiculos_idConductor FOREIGN KEY(idConductor) REFERENCES conductores(idConductor);
ALTER TABLE conductores ADD CONSTRAINT fk_conductores_idConduct FOREIGN KEY(idConductor) REFERENCES personas(id);
ALTER TABLE tarjetasClientes ADD CONSTRAINT fk_tarjetasClientes_idCliente FOREIGN KEY(idCliente) REFERENCES clientes(idCliente);
ALTER TABLE tarjetasClientes ADD CONSTRAINT fk_tarjetasClientes_numeroT FOREIGN KEY(numeroT) REFERENCES tarjetas(numero);
ALTER TABLE anexos ADD CONSTRAINT fk_anexos_idTicked FOREIGN KEY(idTicked) REFERENCES pqrs(ticked);
ALTER TABLE pqrsrespuestas ADD CONSTRAINT fk_pqrsrespuestas FOREIGN KEY (idTicked) REFERENCES pqrs(ticked);
ALTER TABLE pqrs ADD CONSTRAINT fk_pqrs_codigoSolicitud FOREIGN KEY (codigoSolicitud) REFERENCES solicitudes(codigo);
ALTER TABLE requerimientos ADD CONSTRAINT fk_requerimientos_idSolicitud FOREIGN KEY (idSolicitud) REFERENCES solicitudes(codigo);
ALTER TABLE solicitudes ADD CONSTRAINT fk_solicitudes_idCliente FOREIGN KEY (idCliente) REFERENCES clientes(idCliente);
ALTER TABLE solicitudes ADD CONSTRAINT fk_solicitudes_ubicacionInicial FOREIGN KEY (ubicacionInicial) REFERENCES posiciones(ubicacion);
ALTER TABLE solicitudes ADD CONSTRAINT fk_solicitudes_ubicacionFinal FOREIGN KEY (ubicacionFinal) REFERENCES posiciones(ubicacion);
ALTER TABLE clientes ADD CONSTRAINT fk_clientes_idCliente FOREIGN KEY(idCliente) REFERENCES personas(id);

/*---------------------------------------------CICLO 1: XPoblar---------------------------------------------*/
TRUNCATE TABLE personas;
TRUNCATE TABLE conductores;
TRUNCATE TABLE clientes;
TRUNCATE TABLE vehiculos;
TRUNCATE TABLE tarjetasClientes;
TRUNCATE TABLE tarjetas;
TRUNCATE TABLE solicitudes;
TRUNCATE TABLE requerimientos;
TRUNCATE TABLE posiciones;
TRUNCATE TABLE pqrs;
TRUNCATE TABLE anexos;
TRUNCATE TABLE pqrsrespuestas;

/*---------------------------------------------CICLO 1: PoblarOk---------------------------------------------*/
INSERT INTO personas VALUES(1, 'CC',1234567897 , 'Juan Perez', TO_DATE('2023-05-10', 'YYYY-MM-DD'), 1234567890, 'juan@gmail.com');
INSERT INTO personas VALUES(2, 'CC', 9875412345, 'Maria Rodriguez', TO_DATE('2023-06-15', 'YYYY-MM-DD'), 9876543210, 'maria@hotmail.com');
INSERT INTO personas VALUES(3, 'DNI', 5823456987, 'Carlos Sanchez', TO_DATE('1990-03-20', 'YYYY-MM-DD'), 5555555555, 'carlos@gmail.com');
INSERT INTO personas VALUES(4, 'CE', 1000536987, 'Luisa Martinez', TO_DATE('1985-11-28', 'YYYY-MM-DD'), 6666666666, 'luisa@hotmail.com');
INSERT INTO personas VALUES(5, 'TI', 52983610, 'Pedro Lopez', TO_DATE('2023-07-20', 'YYYY-MM-DD'), 7777777777, 'pedro@gmail.com');

INSERT INTO conductores VALUES(1, 'L12345', TO_DATE('1990-03-20', 'YYYY-MM-DD'), 4, 'Activo');
INSERT INTO conductores VALUES(2, 'L54321', TO_DATE('1985-11-28', 'YYYY-MM-DD'), 5, 'Activo');
INSERT INTO conductores VALUES(3, 'L98765', TO_DATE('1995-08-15', 'YYYY-MM-DD'), 3, 'Activo');
INSERT INTO conductores VALUES(4, 'L56789', TO_DATE('1988-06-02', 'YYYY-MM-DD'), 4, 'Ocupado');
INSERT INTO conductores VALUES(5, 'L23456', TO_DATE('1992-12-10', 'YYYY-MM-DD'), 3, 'Activo');

INSERT INTO vehiculos VALUES(1, 'ABC123', '2020', 'M', 'Activo', 0, 1, NULL);
INSERT INTO vehiculos VALUES(2, 'XYZ987', '2018', 'C', 'Activo', 2, 2, 300);
INSERT INTO vehiculos VALUES(3, 'DEF456', '2019', 'M', 'Pendiente', 4, 4, NULL);
INSERT INTO vehiculos VALUES(4, 'GHI789', '2021', 'M', 'Activo', 0, 1, NULL);
INSERT INTO vehiculos VALUES(5, 'JKL321', '2017', 'C', 'Activo', 4, 4, 400);

INSERT INTO clientes VALUES(1, 'Espaniol');
INSERT INTO clientes VALUES(2, 'Ingles');
INSERT INTO clientes VALUES(3, 'Frances');
INSERT INTO clientes VALUES(4, 'Aleman');
INSERT INTO clientes VALUES(5, 'Italiano');

INSERT INTO tarjetas VALUES(123456789012345, 'Visa', TO_DATE('2025-12-31', 'YYYY-MM-DD'));
INSERT INTO tarjetas VALUES(987654321098765, 'Mastercard', TO_DATE('2024-09-30', 'YYYY-MM-DD'));
INSERT INTO tarjetas VALUES(111122223333444, 'American', TO_DATE('2023-11-30', 'YYYY-MM-DD'));
INSERT INTO tarjetas VALUES(555566667777888, 'Visa', TO_DATE('2024-08-31', 'YYYY-MM-DD'));
INSERT INTO tarjetas VALUES(999988887777666, 'Mastercard', TO_DATE('2025-10-31', 'YYYY-MM-DD'));

INSERT INTO tarjetasClientes VALUES(1, 123456789012345);
INSERT INTO tarjetasClientes VALUES(2, 987654321098765);
INSERT INTO tarjetasClientes VALUES(3, 111122223333444);
INSERT INTO tarjetasClientes VALUES(4, 555566667777888);
INSERT INTO tarjetasClientes VALUES(5, 999988887777666);

INSERT INTO posiciones VALUES(1, 40.7128, -74.0060);
INSERT INTO posiciones VALUES(2, 34.0522, -118.2437);
INSERT INTO posiciones VALUES(3, 51.5074, -0.1278);
INSERT INTO posiciones VALUES(4, 52.5200, 13.4050);
INSERT INTO posiciones VALUES(5, 41.8919, 12.5113);

INSERT INTO solicitudes VALUES(1, 1001, TO_DATE('2023-08-01', 'YYYY-MM-DD'), TO_DATE('2023-08-10', 'YYYY-MM-DD'), 'W', 50.00, 'Asignada', 1, 2);
INSERT INTO solicitudes VALUES(2, 1002, TO_DATE('2023-08-02', 'YYYY-MM-DD'), TO_DATE('2023-08-12', 'YYYY-MM-DD'), 'A', 40.00, 'Pendiente', 2, 3);
INSERT INTO solicitudes VALUES(3, 1003, TO_DATE('2023-08-03', 'YYYY-MM-DD'), NULL, 'W', 35.00, 'Pendiente', 3, 4);
INSERT INTO solicitudes VALUES(4, 1004, TO_DATE('2023-08-04', 'YYYY-MM-DD'), TO_DATE('2023-08-15', 'YYYY-MM-DD'), 'A', 60.00, 'Asignada', 4, 5);
INSERT INTO solicitudes VALUES(5, 1005, TO_DATE('2023-08-05', 'YYYY-MM-DD'), TO_DATE('2023-08-14', 'YYYY-MM-DD'), 'W', 45.00, 'Asignada', 5, 1);

INSERT INTO requerimientos VALUES('Musica con ritmo latino', 1001);
INSERT INTO requerimientos VALUES('Asientos comodos', 1002);
INSERT INTO requerimientos VALUES('Musica rock', 1003);
INSERT INTO requerimientos VALUES('Climatizacion', 1004);
INSERT INTO requerimientos VALUES('Conductor amigable', 1005);

INSERT INTO pqrs VALUES(
    'P202310000001',
    1001,
    TO_DATE('2023-10-01', 'YYYY-MM-DD'),
    TO_DATE('2023-10-10', 'YYYY-MM-DD'),
    XMLTYPE('<?xml version="1.0" encoding="UTF-8"?>
            <!DOCTYPE TDescripcion[
                <!ELEMENT TDescripcion (Asunto, Texto, MediosNotificacion*)>
                <!ELEMENT Asunto (#PCDATA)>
                <!ELEMENT Texto (#PCDATA)>
                <!ELEMENT MediosNotificacion (Medio+)>
                <!ELEMENT Medio (Prioridad, Tipo, Valor)>
                <!ELEMENT Prioridad (#PCDATA)>
                <!ELEMENT Tipo (#PCDATA)>
                <!ELEMENT Valor (#PCDATA)>

                ]>
                <TDescripcion>
                    <Asunto>Consulta de Factura</Asunto>
                    <Texto>Necesito información detallada sobre la factura emitida el mes pasado.</Texto>
                    <MediosNotificacion>
                        <Medio>
                            <Prioridad>1</Prioridad>
                            <Tipo>Teléfono</Tipo>
                            <Valor>3133456756</Valor>
                        </Medio>
                        <Medio>
                            <Prioridad>2</Prioridad>
                            <Tipo>Correo electrónico</Tipo>
                            <Valor>cliente@example.com</Valor>
                        </Medio>
                    </MediosNotificacion>
                </TDescripcion>'),
    'P',
    'Cerrado'
);

INSERT INTO pqrs VALUES(
    'P202310000002',
    1002,
    TO_DATE('2023-10-02', 'YYYY-MM-DD'),
    NULL,
    XMLTYPE('<?xml version="1.0" encoding="UTF-8"?>
            <!DOCTYPE TDescripcion[
                <!ELEMENT TDescripcion (Asunto, Texto, MediosNotificacion*)>
                <!ELEMENT Asunto (#PCDATA)>
                <!ELEMENT Texto (#PCDATA)>
                <!ELEMENT MediosNotificacion (Medio+)>
                <!ELEMENT Medio (Prioridad, Tipo, Valor)>
                <!ELEMENT Prioridad (#PCDATA)>
                <!ELEMENT Tipo (#PCDATA)>
                <!ELEMENT Valor (#PCDATA)>

                ]>
                <TDescripcion>
                    <Asunto>Problema de pago</Asunto>
                    <Texto>El cliente experimentó un problema al intentar realizar el pago para el servicio.</Texto>
                    <MediosNotificacion>
                        <Medio>
                            <Prioridad>3</Prioridad>
                            <Tipo>Teléfono</Tipo>
                            <Valor>3135734826</Valor>
                        </Medio>
                    </MediosNotificacion>
                </TDescripcion>'),
    'P',
    'Abierto'
);

INSERT INTO pqrs VALUES(
    'Q202310000003',
    1003,
    TO_DATE('2023-10-03', 'YYYY-MM-DD'),
    NULL,
    XMLTYPE('<?xml version="1.0" encoding="UTF-8"?>
            <!DOCTYPE TDescripcion[
                <!ELEMENT TDescripcion (Asunto, Texto, MediosNotificacion*)>
                <!ELEMENT Asunto (#PCDATA)>
                <!ELEMENT Texto (#PCDATA)>
                <!ELEMENT MediosNotificacion (Medio+)>
                <!ELEMENT Medio (Prioridad, Tipo, Valor)>
                <!ELEMENT Prioridad (#PCDATA)>
                <!ELEMENT Tipo (#PCDATA)>
                <!ELEMENT Valor (#PCDATA)>

                ]>
                <TDescripcion>
                    <Asunto>Música muy alta</Asunto>
                    <Texto>El cliente se queja de que la música en el vehículo estaba demasiado alta durante el viaje.</Texto>
                    <MediosNotificacion>
                        <Medio>
                            <Prioridad>2</Prioridad>
                            <Tipo>Teléfono</Tipo>
                            <Valor>3126534826</Valor>
                        </Medio>
                    </MediosNotificacion>
                </TDescripcion>'),
    'Q',
    'Abierto'
);

INSERT INTO pqrs VALUES(
    'P202310000004',
    1004,
    TO_DATE('2023-10-04', 'YYYY-MM-DD'),
    NULL,
    XMLTYPE('<?xml version="1.0" encoding="UTF-8"?>
            <!DOCTYPE TDescripcion[
                <!ELEMENT TDescripcion (Asunto, Texto, MediosNotificacion*)>
                <!ELEMENT Asunto (#PCDATA)>
                <!ELEMENT Texto (#PCDATA)>
                <!ELEMENT MediosNotificacion (Medio+)>
                <!ELEMENT Medio (Prioridad, Tipo, Valor)>
                <!ELEMENT Prioridad (#PCDATA)>
                <!ELEMENT Tipo (#PCDATA)>
                <!ELEMENT Valor (#PCDATA)>

                ]>
                <TDescripcion>
                    <Asunto>Conductor grosero</Asunto>
                    <Texto>El cliente informa que el conductor fue grosero durante el servicio.</Texto>
                    <MediosNotificacion>
                        <Medio>
                            <Prioridad>3</Prioridad>
                            <Tipo>Teléfono</Tipo>
                            <Valor>3126555726</Valor>
                        </Medio>
                    </MediosNotificacion>
                </TDescripcion>'),
    'P',
    'Abierto'
);

INSERT INTO pqrs VALUES(
    'Q202310000005',
    1005,
    TO_DATE('2023-10-05', 'YYYY-MM-DD'),
    TO_DATE('2023-10-15', 'YYYY-MM-DD'),
    XMLTYPE('<?xml version="1.0" encoding="UTF-8"?>
            <!DOCTYPE TDescripcion[
                <!ELEMENT TDescripcion (Asunto, Texto, MediosNotificacion*)>
                <!ELEMENT Asunto (#PCDATA)>
                <!ELEMENT Texto (#PCDATA)>
                <!ELEMENT MediosNotificacion (Medio+)>
                <!ELEMENT Medio (Prioridad, Tipo, Valor)>
                <!ELEMENT Prioridad (#PCDATA)>
                <!ELEMENT Tipo (#PCDATA)>
                <!ELEMENT Valor (#PCDATA)>

                ]>
                <TDescripcion>
                    <Asunto>Demora en la recogida</Asunto>
                    <Texto>El cliente experimentó una demora en la recogida del servicio.</Texto>
                    <MediosNotificacion>
                        <Medio>
                            <Prioridad>3</Prioridad>
                            <Tipo>Correo Electronico</Tipo>
                            <Valor>correocliente@hotmail.com</Valor>
                        </Medio>
                     </MediosNotificacion>
                </TDescripcion>'),
    'Q',
    'Cerrado'
);


INSERT INTO anexos VALUES(1001, 'P202310000001', 'Captura de pantalla', 'https://example.com/captura.png');
INSERT INTO anexos VALUES(1002, 'P202310000002', 'Audio grabado', 'https://example.com/audio.mp3');
INSERT INTO anexos VALUES(1003, 'Q202310000003', 'Fotos del vehiculo', 'https://example.com/fotos.zip');
INSERT INTO anexos VALUES(1004, 'P202310000004', 'Conversacion chat', 'https://example.com/chat.pdf');
INSERT INTO anexos VALUES(1005, 'Q202310000005', 'Video de incidente', 'https://example.com/video.mp4');

INSERT INTO pqrsrespuestas VALUES('P202310000001', TO_DATE('2023-10-05', 'YYYY-MM-DD'), 'Problema resuelto', 'Soporte', 'soporte@gmail.com', NULL, 5);
INSERT INTO pqrsrespuestas VALUES('P202310000002', TO_DATE('2023-10-07', 'YYYY-MM-DD'), 'Gracias por su feedback', 'Atencion al cliente', 'atencion@outlook.com', 'Estamos trabajando', 4);
INSERT INTO pqrsrespuestas VALUES('Q202310000003', TO_DATE('2023-10-06', 'YYYY-MM-DD'), 'Investigando el incidente', 'Soporte', 'soporte@gmail.com', NULL, NULL);
INSERT INTO pqrsrespuestas VALUES('P202310000004', TO_DATE('2023-10-06', 'YYYY-MM-DD'), 'Entendemos su preocupacion', 'Soporte', 'soporte@gmail.com', 'Estamos trabajando', 3);
INSERT INTO pqrsrespuestas VALUES('Q202310000005', TO_DATE('2023-10-08', 'YYYY-MM-DD'), 'Resoluci n completa', 'Soporte', 'soporte@gmail.com', NULL, 5);

/*---------------------------------------------PoblarNoOK---------------------------------------------*/
INSERT INTO pqrs VALUES(
    'P202310000006',
    1006,
    TO_DATE('2023-10-06', 'YYYY-MM-DD'),
    NULL,
    XMLTYPE('<?xml version="1.0" encoding="UTF-8"?>
            <!DOCTYPE TDescripcion[
                <!ELEMENT TDescripcion (Asunto, Texto, MediosNotificacion*)>
                <!ELEMENT Asunto (#PCDATA)>
                <!ELEMENT Texto (#PCDATA)>
                <!ELEMENT MediosNotificacion (Medio+)>
                <!ELEMENT Medio (Prioridad, Tipo, Valor)>
                <!ELEMENT Prioridad (#PCDATA)>
                <!ELEMENT Tipo (#PCDATA)>
                <!ELEMENT Valor (#PCDATA)>

                ]>
                <TDescripcion>
                    <Asunto>Asunto largo que excede el límite de caracteres</Asunto>
                    <Texto>El cliente se queja de que la música en el vehículo estaba demasiado alta durante el viaje.</Texto>
                    <MediosNotificacion>
                        <Medio>
                            <Prioridad>3</Prioridad>
                            <Tipo>Teléfono</Tipo>
                            <Valor>3126534826</Valor>
                        </Medio>
                    </MediosNotificacion>
                </TDescripcion>'),
    'P',
    'Abierto'
);

INSERT INTO pqrs VALUES(
    'Q202310000006',
    1006,
    TO_DATE('2023-10-06', 'YYYY-MM-DD'),
    TO_DATE('2023-10-15', 'YYYY-MM-DD'),
    XMLTYPE('<?xml version="1.0" encoding="UTF-8"?>
            <!DOCTYPE TDescripcion[
                <!ELEMENT TDescripcion (Asunto, Texto, MediosNotificacion*)>
                <!ELEMENT Asunto (#PCDATA)>
                <!ELEMENT Texto (#PCDATA)>
                <!ELEMENT MediosNotificacion (Medio+)>
                <!ELEMENT Medio (Prioridad, Tipo, Valor)>
                <!ELEMENT Prioridad (#PCDATA)>
                <!ELEMENT Tipo (#PCDATA)>
                <!ELEMENT Valor (#PCDATA)>

                ]>
                <TDescripcion>
                    <Asunto>Asunto largo que excede el límite de caracteres</Asunto>
                    <Texto>El cliente informa que el conductor fue grosero durante el servicio.</Texto>
                    <MediosNotificacion>
                        <Medio>
                            <Prioridad>3</Prioridad>
                            <Tipo>Teléfono</Tipo>
                            <Valor>3126555726</Valor>
                        </Medio>
                    </MediosNotificacion>
                </TDescripcion>'),
    'Q',
    'Cerrado'
);

INSERT INTO pqrs VALUES(
    'Q202310000007',
    1007,
    TO_DATE('2023-10-06', 'YYYY-MM-DD'),
    TO_DATE('2023-10-15', 'YYYY-MM-DD'),
    XMLTYPE('<?xml version="1.0" encoding="UTF-8"?>
            <!DOCTYPE TDescripcion[
                <!ELEMENT TDescripcion (Asunto, Texto, MediosNotificacion*)>
                <!ELEMENT Asunto (#PCDATA)>
                <!ELEMENT Texto (#PCDATA)>
                <!ELEMENT MediosNotificacion (Medio+)>
                <!ELEMENT Medio (Prioridad, Tipo, Valor)>
                <!ELEMENT Prioridad (#PCDATA)>
                <!ELEMENT Tipo (#PCDATA)>
                <!ELEMENT Valor (#PCDATA)>

                ]>
                <TDescripcion>
                    <Asunto>Asunto largo que excede el límite de caracteres</Asunto>
                    <Texto>El cliente informa que el conductor fue grosero durante el servicio.</Texto>
                    <MediosNotificacion>
                        <Medio>
                            <Prioridad>3</Prioridad>
                            <Tipo>Teléfono</Tipo>
                            <Valor>3126555726</Valor>
                        </Medio>
                    </MediosNotificacion>
                </TDescripcion>'),
    'Q',
    'Cerrado'
);
INSERT INTO pqrs VALUES(
    'P202310000008',
    1008,
    TO_DATE('2023-10-06', 'YYYY-MM-DD'),
    TO_DATE('2023-10-15', 'YYYY-MM-DD'),
    XMLTYPE('<?xml version="1.0" encoding="UTF-8"?>
            <!DOCTYPE TDescripcion[
                <!ELEMENT TDescripcion (Asunto, Texto, MediosNotificacion*)>
                <!ELEMENT Asunto (#PCDATA)>
                <!ELEMENT Texto (#PCDATA)>
                <!ELEMENT MediosNotificacion (Medio+)>
                <!ELEMENT Medio (Prioridad, Tipo, Valor)>
                <!ELEMENT Prioridad (#PCDATA)>
                <!ELEMENT Tipo (#PCDATA)>
                <!ELEMENT Valor (#PCDATA)>

                ]>
                <TDescripcion>
                    <Asunto>Asunto largo que excede el límite de caracteres</Asunto>
                    <Texto>El cliente informa que el conductor fue grosero durante el servicio.</Texto>
                    <MediosNotificacion>
                        <Medio>
                            <Prioridad>3</Prioridad>
                            <Tipo>Teléfono</Tipo>
                            <Valor>3126555726</Valor>
                        </Medio>
                    </MediosNotificacion>
                </TDescripcion>'),
    'Q',
    'Cerrado'
);
INSERT INTO pqrs VALUES(
    'Q202310000009',
    1009,
    TO_DATE('2023-10-06', 'YYYY-MM-DD'),
    TO_DATE('2023-10-15', 'YYYY-MM-DD'),
    XMLTYPE('<?xml version="1.0" encoding="UTF-8"?>
            <!DOCTYPE TDescripcion[
                <!ELEMENT TDescripcion (Asunto, Texto, MediosNotificacion*)>
                <!ELEMENT Asunto (#PCDATA)>
                <!ELEMENT Texto (#PCDATA)>
                <!ELEMENT MediosNotificacion (Medio+)>
                <!ELEMENT Medio (Prioridad, Tipo, Valor)>
                <!ELEMENT Prioridad (#PCDATA)>
                <!ELEMENT Tipo (#PCDATA)>
                <!ELEMENT Valor (#PCDATA)>

                ]>
                <TDescripcion>
                    <Asunto>Asunto largo que excede el límite de caracteres</Asunto>
                    <Texto>El cliente informa que el conductor fue grosero durante el servicio.</Texto>
                    <MediosNotificacion>
                        <Medio>
                            <Prioridad>3</Prioridad>
                            <Tipo>Teléfono</Tipo>
                            <Valor>3126555726</Valor>
                        </Medio>
                    </MediosNotificacion>
                </TDescripcion>'),
    'Q',
    'Cerrado'
);

/*---------------------------------------------Consultas---------------------------------------------*/
SELECT
    pq.ticked AS Numero_Ticket,
    pq.codigoSolicitud AS Codigo_Solicitud,
    pq.radicacion AS Fecha_Radicacion,
    pq.cierre AS Fecha_Cierre,
    pq.tipo AS Tipo_PQRS,
    pq.estado AS Estado_PQRS,
    pq.descripcion.extract('//Tipo/text()').getStringVal() AS Tipo_Medio,
    pq.descripcion.extract('//Valor/text()').getStringVal() AS Correo_Electronico
FROM
    pqrs pq
JOIN
    pqrsrespuestas pr ON pq.ticked = pr.idTicked
WHERE
    pq.estado = 'Cerrado'
    AND pq.descripcion.extract('//Tipo/text()').getStringVal() = 'Correo Electronico';
    
/*Consultar los pqrs con prioridad mayor a 2*/
SELECT
    pq.ticked AS Numero_Ticket,
    pq.codigoSolicitud AS Codigo_Solicitud,
    pq.radicacion AS Fecha_Radicacion,
    pq.cierre AS Fecha_Cierre,
    pq.tipo AS Tipo_PQRS,
    pq.estado AS Estado_PQRS,
    pq.descripcion.extract('//Prioridad/text()').getNumberVal() AS Prioridad
FROM
    pqrs pq
JOIN
    pqrsrespuestas pr ON pq.ticked = pr.idTicked
WHERE
    pq.estado = 'Cerrado'
    AND pq.descripcion.extract('//Prioridad/text()').getNumberVal() > 2;
/*-----Punto 5----*/
INSERT INTO pqrs (
    ticked,
    codigoSolicitud,
    radicacion,
    cierre,
    descripcion,
    tipo,
    estado
) VALUES (
    'P202310000006',
    1005,
    TO_DATE('2023-10-06', 'YYYY-MM-DD'),
    TO_DATE('2023-10-20', 'YYYY-MM-DD'),
    XMLTYPE('<?xml version="1.0" encoding="UTF-8"?>
        <!DOCTYPE TDescripcion[
            <!ELEMENT TDescripcion (Asunto, Texto, MediosNotificacion*)>
            <!ELEMENT Asunto (#PCDATA)>
            <!ELEMENT Texto (#PCDATA)>
            <!ELEMENT MediosNotificacion (Medio+)>
            <!ELEMENT Medio (Prioridad, Tipo, Valor)>
            <!ELEMENT Prioridad (#PCDATA)>
            <!ELEMENT Tipo (#PCDATA)>
            <!ELEMENT Valor (#PCDATA)>
            <!ATTLIST Valor
                  emailLength CDATA #REQUIRED
                  uniqueEmail (true|false) #REQUIRED>

        ]>
        <TDescripcion>
            <Asunto>Problema de Servicio</Asunto>
            <Texto>El cliente experimentó un problema con el servicio.</Texto>
            <MediosNotificacion>
                <Medio>
                    <Prioridad>3</Prioridad>
                    <Tipo>Correo Electronico</Tipo>
                    <Valor emailLength="10" uniqueEmail="true">nuevo_correo@example.com</Valor>
                </Medio>
            </MediosNotificacion>
        </TDescripcion>'),
    'P',
    'Cerrado'
);

SELECT
    pq.ticked AS Numero_Ticket,
    pq.codigoSolicitud AS Codigo_Solicitud,
    pq.radicacion AS Fecha_Radicacion,
    pq.cierre AS Fecha_Cierre,
    pq.tipo AS Tipo_PQRS,
    pq.estado AS Estado_PQRS,
    pq.descripcion.extract('//Tipo/text()').getStringVal() AS Tipo_Medio,
    pq.descripcion.extract('//Valor/text()').getStringVal() AS Correo_Electronico
FROM
    pqrs pq
JOIN
    pqrsrespuestas pr ON pq.ticked = pr.idTicked
WHERE
    pq.estado = 'Cerrado'
    AND pq.descripcion.extract('//Tipo/text()').getStringVal() = 'Correo Electronico'
    AND LENGTH(pq.descripcion.extract('//Valor/text()').getStringVal()) <= 80
GROUP BY
    pq.ticked, pq.codigoSolicitud, pq.radicacion, pq.cierre, pq.tipo, pq.estado,
    pq.descripcion.extract('//Tipo/text()').getStringVal(),
    pq.descripcion.extract('//Valor/text()').getStringVal()
HAVING
    COUNT(DISTINCT pq.descripcion.extract('//Valor/text()').getStringVal()) = 1;
